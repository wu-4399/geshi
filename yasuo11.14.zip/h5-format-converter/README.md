# 格式工坊 · FormatLab

一个纯前端的 H5 格式转换工具集：图片、文本编码、结构化数据、开发者常用格式互相转换。
零依赖、零构建、零上传 —— 所有处理都在浏览器本地通过 Web API 完成，文件不会离开设备。

## 功能

| 分类 | 工具 | 说明 |
| --- | --- | --- |
| 图片工具 | 图片格式转换 | PNG / JPG / WEBP 互转，支持多选批量、质量调节、等比缩放、JPG 透明区域填色 |
| 图片工具 | 图片压缩 | 批量压缩，按质量或「压到指定 KB」（自动二分搜索质量 + 必要时缩放），可打包 zip 下载 |
| 图片工具 | 证件照换底色 | 一键替换白 / 蓝 / 红底，自动识别背景色、可吸管取色、7 种标准尺寸、透明背景导出 |
| 图片工具 | 文件 / 图片 ↔ Base64 | 任意文件转 Data URL；Base64 还原为文件并自动识别类型（含图片预览） |
| 文本与编码 | 文本编码转换 | Base64 / Base64URL / URL 百分号 / Hex / Unicode 转义 / HTML 实体 / 二进制 |
| 数据格式 | JSON / YAML / CSV / XML 互转 | 实时转换、语法错误定位（含行列号）、美化 / 压缩输出 |
| 开发者工具 | 颜色格式转换 | HEX、HEX8、RGB(A)、HSL(A)、HSV 互转，附黑白对比度 |
| 开发者工具 | 时间戳转换 | 时间戳 ↔ 日期时间，自动识别秒 / 毫秒，输出 ISO、UTC、相对时间 |
| 开发者工具 | 进制转换 | 2/8/10/16/32 进制互转，BigInt 支持任意大整数，输出位宽与字节数 |
| 开发者工具 | 命名风格转换 | camelCase、PascalCase、snake_case、kebab-case、dot.case 等 |

## 运行

项目没有任何构建步骤，两种方式都可以：

```bash
# 方式一：直接双击 index.html（纯 file:// 即可运行）

# 方式二：起一个静态服务器（推荐，可获得完整的剪贴板 / PWA 能力）
cd h5-format-converter
python -m http.server 5173
# 打开 http://localhost:5173
```

部署时把整个目录丢到任意静态托管（对象存储、Nginx、GitHub Pages、Vercel…）即可。

## 自动化测试

`test.html` 会把 `index.html` 加载进同源 iframe，模拟真实点击（填输入框、选下拉、投递文件、点下载按钮）跑完整流程，结果直接列在页面上。

```bash
# 直接打开（需同源环境，建议用上面的静态服务器）
http://localhost:5173/test.html              # 全部
http://localhost:5173/test.html?only=text    # 只跑文本/数据/开发类
http://localhost:5173/test.html?only=img     # 只跑图片类与 Base64
```

覆盖 **59 项断言**：编码往返（含中文与 emoji）、JSON↔YAML↔XML↔CSV 互转与往返一致性、颜色四种格式互转、时间戳双向与越界、BigInt 大整数进制、9 种命名风格、文件 Base64 往返、PNG→JPEG 真实转码与像素尺寸校验、压缩到指定体积、证件照换底后逐像素取色验证（白/红底 + 人像未被误抠）。

测试用 `window.U.download` 拦截下载，不会真的往磁盘写文件。

## 目录结构

```
h5-format-converter/
├── index.html               # 唯一页面，按分类渲染工具
├── test.html                # 自动化测试页（浏览器里打开即可跑）
├── manifest.json            # PWA 清单（可添加到主屏幕）
├── assets/icon.svg          # 应用图标
├── css/style.css            # 设计令牌 + 全部组件样式（浅色 / 深色主题）
└── js/
    ├── core.js              # 工具函数（U）+ 工具注册表（App）
    ├── app.js               # hash 路由、首页、工具挂载、主题切换
    └── tools/
        ├── img-convert.js   # Canvas 图片转码
        ├── img-compress.js  # 图片压缩 / 目标体积
        ├── id-photo.js      # 证件照换底色
        ├── base64.js        # 文件 / 图片 ↔ Base64
        ├── text-encode.js   # 文本编码转换
        ├── data-convert.js  # JSON / YAML / CSV / XML（内置解析器）
        ├── color.js         # 颜色格式
        ├── timestamp.js     # 时间戳
        ├── radix.js         # 进制
        └── naming.js        # 命名风格
```

## 扩展一个新工具

在 `js/tools/` 下新增文件，然后到 `index.html` 里加一行 `<script>`：

```js
window.App.register({
  id: 'my-tool',          // 会出现在 #/tool/my-tool
  cat: 'dev',             // image | text | data | dev
  name: '我的工具',
  icon: 'zap',            // 见 core.js 中的 ICONS
  desc: '一句话说明',
  tags: ['关键词'],
  mount: function (root) {
    root.innerHTML = '<div class="panel">…</div>';
    // 在这里绑定事件
  }
});
```

首页的分类、搜索、路由都会自动生效，无需改动其他文件。

## 实现要点

- **图片转码**：`<img>` 解码 → `canvas.drawImage` 重绘 → `canvas.toBlob(mime, quality)`。JPEG 不支持透明，转换前会先用背景色填充画布；GIF 只取第一帧；SVG 按原始尺寸渲染。
- **按体积压缩**：在 `[0.2, 0.95]` 区间二分搜索质量（6 次采样），命中不了目标时按 85% 逐级缩小尺寸重试（最多 3 轮），最终结果会标注实际质量。PNG 是无损格式，质量参数对它无效，「压到指定体积」时会自动改用 JPG 并在结果里注明原因。
- **JSON 错误定位**：内置一个递归下降的 JSON 语法扫描器（`scanJSONError`）。旧版 Chrome 的 `JSON.parse` 报错带 `position`，新版已取消，因此不依赖浏览器错误文案，自己算出出错偏移量并换算成「第 N 行第 M 列」，同时给出原因（如“缺少逗号或右花括号”）。
- **证件照换底色**：取画面四周边缘像素做颜色分桶统计，出现最多的桶即背景色；逐像素计算与背景色的 RGB 距离，`距离 ≤ 容差` 判为背景替换成新底色，容差到容差+羽化区间做线性过渡，避免锯齿硬边。
- **标准尺寸**：按 300dpi 输出（一寸 295×413、二寸 413×579 等），原图按 `cover` 方式裁切，可用垂直位置滑块微调人物构图。
- **中文 Base64**：先用 `TextEncoder` 转 UTF-8 字节，再分块 `btoa`，避免 `btoa` 只支持 Latin-1 的坑；解码走 `TextDecoder`。
- **YAML**：内置缩进式解析器，支持对象、数组、行内 `[]` / `{}`、引号、注释、`|` 与 `>` 块标量，覆盖常见配置文件的绝大多数写法；复杂锚点（`&` / `*`）与多文档未实现。
- **CSV**：手写状态机处理引号包裹、`""` 转义、字段内换行，并自动识别逗号 / 制表符分隔。
- **XML**：`DOMParser` 解析为「属性 `@name` + 子节点 + `#text`」的对象结构，可无损往返。
- **主题**：CSS 变量 + `data-theme`，跟随系统偏好并记忆用户选择。

## 浏览器支持

Chrome / Edge / Firefox 90+、Safari 15+、移动端 WebView 均可。
`canvas.toBlob('image/webp')` 在部分旧版 Safari 不受支持，此时会提示并回退，不会静默失败。

## 已知边界

- 不支持的转换：Office / PDF / 音视频转码（需要 WASM 或服务端，超出纯前端范围）。
- Base64 处理超大文件（>20MB）会占用较多内存，页面会给出提示。
- YAML 仅实现常用子集，不作为通用 YAML 1.2 实现。
- 证件照抠图基于颜色差异，**只适合纯色背景**（影楼白/蓝/红底）。背景有渐变、纹理或人物与背景颜色接近（如白衬衫 + 白底）时，需要用容差和羽化手动微调，效果不如 AI 分割模型。

## 下载受限环境（内嵌预览）的处理

浏览器会把「嵌入在 `sandbox` iframe 里的页面」的下载请求**静默丢弃**（sandbox 未含
`allow-downloads` 时），控制台只留一行提示，网页代码无法捕获。项目对此做了自动兜底：

- 页面加载时检测自身是否处于受限 iframe，是则在顶栏下方显示一次性提示条
  （「在新窗口打开 / 复制地址」，可关闭，关闭状态记入 localStorage）。
- 点「下载」时若检测到受限，除照常发起下载外，还会弹出**保存面板**：
  文件名 + 大小（图片类附带预览图）+ 三个操作 —— 在新窗口打开、再试一次下载、
  复制页面地址；图片可直接右键 / 长按另存。

最稳的用法始终是：把 `index.html` 在系统浏览器中直接打开（双击本地文件即可），
此时所有下载行为与普通网站一致。
