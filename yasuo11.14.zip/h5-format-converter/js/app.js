/* ==========================================================================
 * 格式工坊 · app.js
 * 路由（hash）、首页渲染、工具页挂载、主题切换
 * ========================================================================== */
(function () {
  'use strict';

  var U = window.U;
  var App = window.App;
  var $ = U.$, $$ = U.$$;

  var CATS = [
    { id: 'image', name: '图片工具', icon: 'image', desc: '格式互转 · 压缩 · Base64' },
    { id: 'text', name: '文本与编码', icon: 'code', desc: 'Base64 / URL / Hex / Unicode' },
    { id: 'data', name: '数据格式', icon: 'braces', desc: 'JSON / YAML / CSV / XML' },
    { id: 'dev', name: '开发者工具', icon: 'zap', desc: '颜色 · 时间 · 进制 · 命名' }
  ];

  var view = $('#view');

  /* ---------------------------- 主题 ---------------------------- */
  var THEME_KEY = 'formatlab.theme';

  function applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    var btn = $('#themeBtn');
    if (btn) {
      btn.innerHTML = U.icon(theme === 'dark' ? 'sun' : 'moon', 18);
      btn.setAttribute('title', theme === 'dark' ? '切换到浅色' : '切换到深色');
      var meta = document.querySelector('meta[name="theme-color"]');
      if (meta) meta.setAttribute('content', theme === 'dark' ? '#0c0e15' : '#5b5ef0');
    }
    try { localStorage.setItem(THEME_KEY, theme); } catch (e) { /* 忽略隐私模式报错 */ }
  }

  function initTheme() {
    var saved = null;
    try { saved = localStorage.getItem(THEME_KEY); } catch (e) { saved = null; }
    var prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
    applyTheme(saved || (prefersDark ? 'dark' : 'light'));
    $('#themeBtn').addEventListener('click', function () {
      var cur = document.documentElement.getAttribute('data-theme');
      applyTheme(cur === 'dark' ? 'light' : 'dark');
    });
  }

  /* ---------------------------- 首页 ---------------------------- */
  function cardHTML(t) {
    var key = (t.name + ' ' + t.desc + ' ' + (t.tags || []).join(' ')).toLowerCase();
    return (
      '<a class="card" href="#/tool/' + t.id + '" data-search="' + U.escapeHtml(key) + '">' +
        '<span class="card-ico">' + U.icon(t.icon, 21) + '</span>' +
        '<span class="card-body"><b>' + U.escapeHtml(t.name) + '</b><span>' + U.escapeHtml(t.desc) + '</span></span>' +
        '<span class="card-arrow">' + U.icon('arrow', 16) + '</span>' +
      '</a>'
    );
  }

  function renderHome() {
    document.title = '格式工坊 · FormatLab';

    var sections = CATS.map(function (cat) {
      var list = App.tools.filter(function (t) { return t.cat === cat.id; });
      if (!list.length) return '';
      return (
        '<section class="cat" data-cat="' + cat.id + '">' +
          '<div class="cat-head">' +
            '<span class="cat-ico">' + U.icon(cat.icon, 15) + '</span>' +
            '<h3>' + U.escapeHtml(cat.name) + '</h3>' +
            '<span class="cat-desc">' + U.escapeHtml(cat.desc) + '</span>' +
          '</div>' +
          '<div class="grid">' + list.map(cardHTML).join('') + '</div>' +
        '</section>'
      );
    }).join('');

    view.innerHTML =
      '<section class="hero">' +
        '<span class="badge">纯前端 · 无需上传</span>' +
        '<h1>一处转换，<span class="grad">所有格式</span></h1>' +
        '<p class="hero-sub">图片、文本编码、结构化数据与开发者常用格式互转。所有处理都在浏览器本地完成，文件不会离开你的设备。</p>' +
        '<div class="search">' + U.icon('search', 18) +
          '<input id="q" type="search" placeholder="搜索：图片 / Base64 / JSON / 颜色 / 时间戳…" autocomplete="off" />' +
        '</div>' +
      '</section>' +
      '<div id="cats">' + sections + '</div>' +
      '<p class="empty" id="empty" hidden>没有找到匹配的工具，换个关键词试试。</p>';

    var q = $('#q');
    var catsEl = $('#cats');

    q.addEventListener('input', function () {
      var kw = q.value.trim().toLowerCase();
      var total = 0;
      $$('.card', catsEl).forEach(function (card) {
        var hit = !kw || (card.getAttribute('data-search') || '').indexOf(kw) !== -1;
        card.hidden = !hit;
        if (hit) total++;
      });
      $$('.cat', catsEl).forEach(function (sec) {
        sec.hidden = !$$('.card', sec).some(function (c) { return !c.hidden; });
      });
      $('#empty').hidden = total > 0;
    });
  }

  /* ---------------------------- 工具页 ---------------------------- */
  function renderTool(id) {
    var tool = App.byId(id);
    if (!tool) { location.hash = '#/'; return; }

    document.title = tool.name + ' · 格式工坊';
    view.innerHTML =
      '<div class="tool-head">' +
        '<a class="back" href="#/">' + U.icon('back', 14) + ' 全部工具</a>' +
        '<div class="tool-title">' +
          '<span class="tool-ico">' + U.icon(tool.icon, 19) + '</span>' +
          '<h2>' + U.escapeHtml(tool.name) + '</h2>' +
        '</div>' +
        '<p class="tool-desc">' + U.escapeHtml(tool.desc) + '</p>' +
      '</div>' +
      '<div class="tool-body"></div>';

    try {
      tool.mount(view.querySelector('.tool-body'));
    } catch (err) {
      view.querySelector('.tool-body').innerHTML =
        '<div class="panel"><p class="err">工具加载失败：' + U.escapeHtml(err.message) + '</p></div>';
      console.error(err);
    }
    window.scrollTo({ top: 0, behavior: 'auto' });
  }

  /* ---------------------------- 路由 ---------------------------- */
  function route() {
    var hash = location.hash || '#/';
    var m = hash.match(/^#\/tool\/([A-Za-z0-9_-]+)/);
    if (m) renderTool(m[1]);
    else renderHome();
  }

  /* ---------------------------- 环境提示 ----------------------------
   * 内嵌预览（sandbox iframe）会静默拦截下载，提前告知并给出出口。
   * --------------------------------------------------------------- */
  var ENV_KEY = 'formatlab.envbar.dismissed';

  function initEnvNotice() {
    if (!U.downloadBlocked()) return;
    var dismissed = false;
    try { dismissed = localStorage.getItem(ENV_KEY) === '1'; } catch (e) { dismissed = false; }
    if (dismissed) return;

    var bar = document.createElement('div');
    bar.className = 'envbar';
    bar.innerHTML =
      '<div class="wrap envbar-inner">' +
        U.icon('file', 16) +
        '<span>当前在预览窗口内，浏览器会拦截文件下载。点“在新窗口打开”后即可正常保存。</span>' +
        '<button class="btn mini primary" type="button" data-act="open">在新窗口打开</button>' +
        '<button class="btn mini" type="button" data-act="copy">复制地址</button>' +
        '<button class="envbar-x" type="button" data-act="close" aria-label="关闭提示">' + U.icon('close', 14) + '</button>' +
      '</div>';

    bar.addEventListener('click', function (e) {
      var btn = e.target.closest('[data-act]');
      if (!btn) return;
      var act = btn.getAttribute('data-act');
      if (act === 'open') {
        var w = null;
        try { w = window.open(location.href, '_blank'); } catch (err) { w = null; }
        if (!w) U.toast('被拦截了，请复制地址后在浏览器中打开', 'err');
      } else if (act === 'copy') {
        U.copy(location.href);
      } else if (act === 'close') {
        bar.remove();
        try { localStorage.setItem(ENV_KEY, '1'); } catch (err) { /* 忽略 */ }
      }
    });

    var topbar = document.querySelector('.topbar');
    if (topbar && topbar.parentNode) topbar.parentNode.insertBefore(bar, topbar.nextSibling);
  }

  /* ---------------------------- 启动 ---------------------------- */
  initTheme();
  initEnvNotice();
  window.addEventListener('hashchange', route);
  route();

  var foot = $('#footCount');
  if (foot) foot.textContent = App.tools.length + ' 个转换工具 · 零依赖';
})();
