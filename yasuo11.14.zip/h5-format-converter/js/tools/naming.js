/* ==========================================================================
 * 工具：命名风格转换（camelCase / snake_case / kebab-case …）
 * ========================================================================== */
(function () {
  'use strict';

  var U = window.U;
  var $ = U.$, esc = U.escapeHtml;

  function splitWords(input) {
    var s = String(input || '').trim();
    if (!s) return [];
    return s
      .replace(/([a-z0-9])([A-Z])/g, '$1 $2')
      .replace(/([A-Z]+)([A-Z][a-z])/g, '$1 $2')
      .replace(/([a-zA-Z])(\d)/g, '$1 $2')
      .replace(/(\d)([a-zA-Z])/g, '$1 $2')
      .split(/[^A-Za-z0-9\u4e00-\u9fa5]+/)
      .filter(Boolean)
      .map(function (w) { return w.toLowerCase(); });
  }

  function cap(w) { return w ? w.charAt(0).toUpperCase() + w.slice(1) : ''; }

  window.App.register({
    id: 'naming',
    cat: 'dev',
    name: '命名风格转换',
    icon: 'type',
    desc: '在 camelCase、snake_case、kebab-case 等写法间切换',
    tags: ['命名', 'camel', 'snake', 'kebab', '变量名', '命名规范', 'naming'],
    mount: function (root) {
      root.innerHTML =
        '<div class="panel">' +
          '<label class="field">' +
            '<span>输入标识符或文案（支持空格、下划线、驼峰）</span>' +
            '<input class="control" id="txt" value="user profile image url" spellcheck="false" />' +
          '</label>' +
          '<div id="rows" class="rows"></div>' +
          '<div class="err" id="err"></div>' +
        '</div>';

      var txt = $('#txt', root);
      var rowsEl = $('#rows', root);
      var errEl = $('#err', root);
      var values = [];

      rowsEl.addEventListener('click', function (e) {
        var btn = e.target.closest('[data-i]');
        if (!btn) return;
        U.copy(values[Number(btn.getAttribute('data-i'))]);
      });

      function update() {
        var words = splitWords(txt.value);
        errEl.textContent = '';
        if (!words.length) {
          rowsEl.innerHTML = '';
          errEl.textContent = '请输入字母、数字或中文';
          return;
        }

        var list = [
          ['camelCase', words[0] + words.slice(1).map(cap).join('')],
          ['PascalCase', words.map(cap).join('')],
          ['snake_case', words.join('_')],
          ['CONSTANT', words.join('_').toUpperCase()],
          ['kebab-case', words.join('-')],
          ['dot.case', words.join('.')],
          ['Title Case', words.map(cap).join(' ')],
          ['sentence', cap(words.join(' '))],
          ['大写', words.join(' ').toUpperCase()],
          ['单词数', String(words.length)]
        ];

        values = list.map(function (x) { return x[1]; });
        rowsEl.innerHTML = list.map(function (x, i) {
          return '<div class="kv"><span class="kv-k">' + esc(x[0]) + '</span>' +
            '<code class="kv-v">' + esc(x[1]) + '</code>' +
            (x[0] === '单词数' ? '' : '<button class="btn mini" type="button" data-i="' + i + '">复制</button>') +
            '</div>';
        }).join('');
      }

      txt.addEventListener('input', update);
      update();
    }
  });
})();
