/* ==========================================================================
 * 工具：时间戳 ↔ 日期互转
 * ========================================================================== */
(function () {
  'use strict';

  var U = window.U;
  var $ = U.$, toast = U.toast, esc = U.escapeHtml;

  function pad2(n) { return String(n).padStart(2, '0'); }

  function fmtLocal(d) {
    return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate()) + ' ' +
      pad2(d.getHours()) + ':' + pad2(d.getMinutes()) + ':' + pad2(d.getSeconds());
  }

  var WEEK = ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'];

  function relative(ms) {
    var diff = Date.now() - ms;
    var abs = Math.abs(diff);
    var units = [
      [31536000000, '年'], [2592000000, '个月'], [604800000, '周'],
      [86400000, '天'], [3600000, '小时'], [60000, '分钟'], [1000, '秒']
    ];
    for (var i = 0; i < units.length; i++) {
      if (abs >= units[i][0]) {
        var n = Math.floor(abs / units[i][0]);
        return diff > 0 ? n + ' ' + units[i][1] + '前' : n + ' ' + units[i][1] + '后';
      }
    }
    return '刚刚';
  }

  function parseTs(raw) {
    var s = String(raw).trim().replace(/[,\s_]/g, '');
    if (!s) throw new Error('请输入时间戳');
    if (!/^-?\d+(\.\d+)?$/.test(s)) throw new Error('时间戳只能包含数字');
    var n = Number(s);
    if (!isFinite(n)) throw new Error('数值超出范围');
    var isSeconds = Math.abs(n) < 1e11;
    return { ms: isSeconds ? n * 1000 : n, unit: isSeconds ? '秒' : '毫秒' };
  }

  window.App.register({
    id: 'timestamp',
    cat: 'dev',
    name: '时间戳转换',
    icon: 'clock',
    desc: 'Unix 时间戳与日期时间互转，自动识别秒 / 毫秒',
    tags: ['时间戳', 'timestamp', 'unix', '日期', '时间', 'iso', 'utc'],
    mount: function (root) {
      root.innerHTML =
        '<div class="panel">' +
          '<div class="field">' +
            '<span>时间戳（自动识别秒 / 毫秒）</span>' +
            '<input class="control" id="ts" value="' + Math.floor(Date.now() / 1000) + '" inputmode="numeric" spellcheck="false" />' +
          '</div>' +
          '<div class="actions">' +
            '<button class="btn primary" id="now" type="button">使用当前时间</button>' +
            '<button class="btn ghost" id="msBtn" type="button">切换为毫秒</button>' +
            '<span class="hint" id="unit"></span>' +
          '</div>' +
          '<div id="rows" class="rows"></div>' +
          '<div class="err" id="err"></div>' +
        '</div>' +

        '<div class="panel">' +
          '<div class="grid2">' +
            '<label class="field"><span>选择日期时间（本地时区）</span>' +
              '<input class="control" type="datetime-local" id="dt" step="1" />' +
            '</label>' +
            '<label class="field"><span>或手动填写</span>' +
              '<input class="control" id="dtText" placeholder="2026-11-14 15:30:00" spellcheck="false" />' +
            '</label>' +
          '</div>' +
          '<div id="rows2" class="rows"></div>' +
          '<div class="err" id="err2"></div>' +
        '</div>';

      var ts = $('#ts', root);
      var rowsEl = $('#rows', root);
      var errEl = $('#err', root);
      var unitEl = $('#unit', root);
      var values = [];

      function renderRows(el, list) {
        el.innerHTML = list.map(function (x, i) {
          return '<div class="kv"><span class="kv-k">' + esc(x[0]) + '</span>' +
            '<code class="kv-v">' + esc(x[1]) + '</code>' +
            '<button class="btn mini" type="button" data-copy="' + i + '">复制</button></div>';
        }).join('');
      }

      var store1 = [], store2 = [];

      function update() {
        errEl.textContent = '';
        try {
          var p = parseTs(ts.value);
          var d = new Date(p.ms);
          if (isNaN(d.getTime())) throw new Error('时间戳超出可表示范围');
          unitEl.textContent = '按' + p.unit + '解析';
          var list = [
            ['本地时间', fmtLocal(d)],
            ['星期', WEEK[d.getDay()]],
            ['ISO 8601', d.toISOString()],
            ['UTC', d.toUTCString()],
            ['相对现在', relative(p.ms)],
            ['秒级', String(Math.floor(p.ms / 1000))],
            ['毫秒级', String(Math.round(p.ms))],
            ['日期', d.getFullYear() + ' 年 ' + (d.getMonth() + 1) + ' 月 ' + d.getDate() + ' 日']
          ];
          store1 = list.map(function (x) { return x[1]; });
          renderRows(rowsEl, list);
        } catch (e) {
          unitEl.textContent = '';
          rowsEl.innerHTML = '';
          errEl.textContent = '⚠ ' + e.message;
        }
      }

      rowsEl.addEventListener('click', function (e) {
        var btn = e.target.closest('[data-copy]');
        if (btn) U.copy(store1[Number(btn.getAttribute('data-copy'))]);
      });

      ts.addEventListener('input', update);

      $('#now', root).addEventListener('click', function () {
        ts.value = Math.floor(Date.now() / 1000);
        update();
      });

      $('#msBtn', root).addEventListener('click', function () {
        try {
          var val = parseTs(ts.value);
          ts.value = val.unit === '秒' ? Math.round(val.ms) : Math.floor(val.ms / 1000);
          update();
        } catch (e) { toast(e.message, 'err'); }
      });

      /* ---------- 日期 → 时间戳 ---------- */
      var dt = $('#dt', root);
      var dtText = $('#dtText', root);
      var rows2 = $('#rows2', root);
      var err2 = $('#err2', root);

      function toLocalInput(d) {
        return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate()) + 'T' +
          pad2(d.getHours()) + ':' + pad2(d.getMinutes()) + ':' + pad2(d.getSeconds());
      }

      function fromDate(d, syncInput) {
        if (isNaN(d.getTime())) {
          rows2.innerHTML = '';
          err2.textContent = '⚠ 无法解析该日期';
          return;
        }
        err2.textContent = '';
        if (syncInput) dt.value = toLocalInput(d);
        var sec = Math.floor(d.getTime() / 1000);
        var list = [
          ['秒级时间戳', String(sec)],
          ['毫秒时间戳', String(d.getTime())],
          ['本地时间', fmtLocal(d)],
          ['ISO 8601', d.toISOString()],
          ['相对现在', relative(d.getTime())]
        ];
        store2 = list.map(function (x) { return x[1]; });
        renderRows(rows2, list);
      }

      rows2.addEventListener('click', function (e) {
        var btn = e.target.closest('[data-copy]');
        if (btn) U.copy(store2[Number(btn.getAttribute('data-copy'))]);
      });

      dt.addEventListener('input', function () {
        if (!dt.value) return;
        fromDate(new Date(dt.value), false);
      });

      dtText.addEventListener('input', U.debounce(function () {
        var raw = dtText.value.trim();
        if (!raw) return;
        var norm = raw.replace(/[年月]/g, '-').replace(/[日]/g, '').replace(/\//g, '-').replace(/\s+/, 'T');
        var d = new Date(norm);
        if (isNaN(d.getTime())) d = new Date(raw.replace(/-/g, '/'));
        fromDate(d, true);
      }, 400));

      var init = new Date();
      dt.value = toLocalInput(init);
      dtText.value = fmtLocal(init);
      update();
      fromDate(init, false);
    }
  });
})();
