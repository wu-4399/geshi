/* ==========================================================================
 * 工具：颜色格式转换（HEX / RGB / HSL / HSV / 对比度）
 * ========================================================================== */
(function () {
  'use strict';

  var U = window.U;
  var $ = U.$, toast = U.toast, esc = U.escapeHtml;

  function clamp(n, min, max) { return Math.min(max, Math.max(min, n)); }
  function pad2(n) { return String(n).padStart(2, '0'); }

  function rgbToHex(r, g, b) {
    return '#' + [r, g, b].map(function (v) {
      return pad2(clamp(Math.round(v), 0, 255).toString(16));
    }).join('').toUpperCase();
  }

  function rgbToHsl(r, g, b) {
    r /= 255; g /= 255; b /= 255;
    var max = Math.max(r, g, b), min = Math.min(r, g, b);
    var h = 0, s = 0, l = (max + min) / 2;
    if (max !== min) {
      var d = max - min;
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      if (max === r) h = (g - b) / d + (g < b ? 6 : 0);
      else if (max === g) h = (b - r) / d + 2;
      else h = (r - g) / d + 4;
      h *= 60;
    }
    return { h: Math.round(h) % 360, s: Math.round(s * 100), l: Math.round(l * 100) };
  }

  function hslToRgb(h, s, l) {
    h = ((h % 360) + 360) % 360;
    s = clamp(s, 0, 100) / 100;
    l = clamp(l, 0, 100) / 100;
    var c = (1 - Math.abs(2 * l - 1)) * s;
    var x = c * (1 - Math.abs((h / 60) % 2 - 1));
    var m = l - c / 2;
    var r = 0, g = 0, b = 0;
    if (h < 60) { r = c; g = x; }
    else if (h < 120) { r = x; g = c; }
    else if (h < 180) { g = c; b = x; }
    else if (h < 240) { g = x; b = c; }
    else if (h < 300) { r = x; b = c; }
    else { r = c; b = x; }
    return { r: Math.round((r + m) * 255), g: Math.round((g + m) * 255), b: Math.round((b + m) * 255) };
  }

  function rgbToHsv(r, g, b) {
    r /= 255; g /= 255; b /= 255;
    var max = Math.max(r, g, b), min = Math.min(r, g, b), d = max - min;
    var h = 0;
    if (d) {
      if (max === r) h = ((g - b) / d) % 6;
      else if (max === g) h = (b - r) / d + 2;
      else h = (r - g) / d + 4;
      h *= 60;
      if (h < 0) h += 360;
    }
    return {
      h: Math.round(h),
      s: Math.round((max ? d / max : 0) * 100),
      v: Math.round(max * 100)
    };
  }

  function luminance(c) {
    var a = [c.r, c.g, c.b].map(function (v) {
      v /= 255;
      return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
    });
    return 0.2126 * a[0] + 0.7152 * a[1] + 0.0722 * a[2];
  }

  function contrast(l1, l2) {
    var hi = Math.max(l1, l2), lo = Math.min(l1, l2);
    return (hi + 0.05) / (lo + 0.05);
  }

  function num(v, scale) {
    if (v === undefined) return NaN;
    if (/%$/.test(v)) return Math.round(parseFloat(v) / 100 * scale);
    return parseFloat(v);
  }

  function parseColor(input) {
    var s = String(input || '').trim().toLowerCase();
    if (!s) return null;

    var hex = s.replace(/^#/, '');
    if (/^[0-9a-f]+$/.test(hex) && [3, 4, 6, 8].indexOf(hex.length) !== -1) {
      var full = hex.length <= 4 ? hex.split('').map(function (c) { return c + c; }).join('') : hex;
      return {
        r: parseInt(full.slice(0, 2), 16),
        g: parseInt(full.slice(2, 4), 16),
        b: parseInt(full.slice(4, 6), 16),
        a: full.length === 8 ? +(parseInt(full.slice(6, 8), 16) / 255).toFixed(2) : 1
      };
    }

    var m = s.match(/^rgba?\(([^)]+)\)$/);
    if (m) {
      var p = m[1].split(/[,\s\/]+/).filter(Boolean);
      if (p.length < 3) return null;
      var r = num(p[0], 255), g = num(p[1], 255), b = num(p[2], 255);
      if ([r, g, b].some(isNaN)) return null;
      var a = p[3] === undefined ? 1 : (/%$/.test(p[3]) ? parseFloat(p[3]) / 100 : parseFloat(p[3]));
      return { r: clamp(r, 0, 255), g: clamp(g, 0, 255), b: clamp(b, 0, 255), a: isNaN(a) ? 1 : clamp(a, 0, 1) };
    }

    m = s.match(/^hsla?\(([^)]+)\)$/);
    if (m) {
      var q = m[1].split(/[,\s\/]+/).filter(Boolean);
      if (q.length < 3) return null;
      var h = parseFloat(q[0]), sat = parseFloat(q[1]), li = parseFloat(q[2]);
      if ([h, sat, li].some(isNaN)) return null;
      var rgb = hslToRgb(h, sat, li);
      var al = q[3] === undefined ? 1 : (/%$/.test(q[3]) ? parseFloat(q[3]) / 100 : parseFloat(q[3]));
      return { r: rgb.r, g: rgb.g, b: rgb.b, a: isNaN(al) ? 1 : clamp(al, 0, 1) };
    }

    return null;
  }

  window.App.register({
    id: 'color',
    cat: 'dev',
    name: '颜色格式转换',
    icon: 'palette',
    desc: 'HEX / RGB / HSL / HSV 互转，附带对比度检查',
    tags: ['颜色', 'color', 'hex', 'rgb', 'hsl', 'hsv', '对比度', '配色'],
    mount: function (root) {
      root.innerHTML =
        '<div class="panel">' +
          '<div class="grid2">' +
            '<label class="field"><span>颜色值（支持 #5B5EF0 / rgb() / hsl()）</span>' +
              '<input class="control" id="txt" value="#5B5EF0" spellcheck="false" />' +
            '</label>' +
            '<label class="field"><span>取色器</span>' +
              '<input class="control" type="color" id="pick" value="#5b5ef0" />' +
            '</label>' +
          '</div>' +
          '<div class="swatch" id="swatch" style="margin-top:14px">#5B5EF0</div>' +
          '<div id="rows" class="rows"></div>' +
          '<div class="err" id="err"></div>' +
        '</div>';

      var txt = $('#txt', root);
      var pick = $('#pick', root);
      var swatch = $('#swatch', root);
      var rowsEl = $('#rows', root);
      var errEl = $('#err', root);

      var values = [];

      function renderRows(list) {
        values = list.map(function (x) { return x[1]; });
        rowsEl.innerHTML = list.map(function (x, i) {
          return '<div class="kv"><span class="kv-k">' + esc(x[0]) + '</span>' +
            '<code class="kv-v">' + esc(x[1]) + '</code>' +
            '<button class="btn mini" type="button" data-i="' + i + '">复制</button></div>';
        }).join('');
      }

      rowsEl.addEventListener('click', function (e) {
        var btn = e.target.closest('[data-i]');
        if (!btn) return;
        U.copy(values[Number(btn.getAttribute('data-i'))]);
      });

      function update(fromPicker) {
        var raw = fromPicker ? pick.value : txt.value;
        var c = parseColor(raw);
        if (!c) {
          errEl.textContent = txt.value.trim() ? '无法识别的颜色格式，试试 #5b5ef0、rgb(91,94,240) 或 hsl(239,84%,65%)' : '';
          swatch.style.background = 'var(--surface-2)';
          swatch.textContent = txt.value || '—';
          rowsEl.innerHTML = '';
          return;
        }
        errEl.textContent = '';
        var hex = rgbToHex(c.r, c.g, c.b);
        var hex8 = hex + pad2(Math.round(c.a * 255).toString(16)).toUpperCase();
        var hsl = rgbToHsl(c.r, c.g, c.b);
        var hsv = rgbToHsv(c.r, c.g, c.b);
        var lum = luminance(c);

        if (!fromPicker) pick.value = hex.toLowerCase();
        swatch.style.background = c.a < 1
          ? 'linear-gradient(' + hex + ',' + hex + '), conic-gradient(#ccc 25%,#fff 0 50%,#ccc 0 75%,#fff 0)'
          : hex;
        swatch.style.backgroundSize = c.a < 1 ? '100% 100%, 16px 16px' : '';
        swatch.style.backgroundBlendMode = c.a < 1 ? 'multiply' : '';
        swatch.style.color = lum > 0.45 ? '#111827' : '#ffffff';
        swatch.textContent = hex;

        renderRows([
          ['HEX', hex],
          ['HEX 8 位', hex8],
          ['RGB', 'rgb(' + c.r + ', ' + c.g + ', ' + c.b + ')'],
          ['RGBA', 'rgba(' + c.r + ', ' + c.g + ', ' + c.b + ', ' + c.a + ')'],
          ['HSL', 'hsl(' + hsl.h + ', ' + hsl.s + '%, ' + hsl.l + '%)'],
          ['HSLA', 'hsla(' + hsl.h + ', ' + hsl.s + '%, ' + hsl.l + '%, ' + c.a + ')'],
          ['HSV', 'hsv(' + hsv.h + ', ' + hsv.s + '%, ' + hsv.v + '%)'],
          ['CSS 变量', '--color: ' + hex + ';'],
          ['白色对比度', contrast(lum, 1).toFixed(2) + ':1'],
          ['黑色对比度', contrast(lum, 0).toFixed(2) + ':1']
        ]);
      }

      txt.addEventListener('input', function () { update(false); });
      pick.addEventListener('input', function () {
        txt.value = pick.value.toUpperCase();
        update(true);
      });
      update(false);
    }
  });
})();
