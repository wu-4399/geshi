/* ==========================================================================
 * 工具：图片压缩（按质量 / 按目标体积，自动二分搜索质量）
 * ========================================================================== */
(function () {
  'use strict';

  var U = window.U;
  var $ = U.$, icon = U.icon, toast = U.toast, formatBytes = U.formatBytes, esc = U.escapeHtml;

  var EXT = { 'image/png': 'png', 'image/jpeg': 'jpg', 'image/webp': 'webp' };

  function pickMime(file, choice) {
    if (choice === 'jpeg') return 'image/jpeg';
    if (choice === 'webp') return 'image/webp';
    if (choice === 'png') return 'image/png';
    // keep
    if (/jpe?g/i.test(file.type)) return 'image/jpeg';
    if (/webp/i.test(file.type)) return 'image/webp';
    if (/png/i.test(file.type)) return 'image/png';
    return 'image/jpeg';
  }

  function baseName(name) {
    return String(name || 'image').replace(/\.[^.]+$/, '') || 'image';
  }

  function drawTo(src, w, h, mime) {
    var canvas = document.createElement('canvas');
    canvas.width = w;
    canvas.height = h;
    var ctx = canvas.getContext('2d');
    if (mime === 'image/jpeg') {
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, w, h);
    }
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(src, 0, 0, w, h);
    return canvas;
  }

  /* 在 [0.2, 0.95] 内二分搜索最接近目标体积的质量 */
  async function bestQuality(canvas, mime, targetBytes) {
    var lo = 0.2, hi = 0.95, best = null;
    for (var i = 0; i < 6; i++) {
      var mid = (lo + hi) / 2;
      var blob = await U.canvasToBlob(canvas, mime, mid);
      if (blob.size <= targetBytes) {
        best = { blob: blob, quality: mid };
        lo = mid;
      } else {
        hi = mid;
      }
    }
    if (!best) best = { blob: await U.canvasToBlob(canvas, mime, 0.2), quality: 0.2 };
    return best;
  }

  async function compressOne(file, opt) {
    var loaded = await U.loadImage(file);
    var img = loaded.img;
    var mime = pickMime(file, opt.format);

    /* PNG 是无损格式，质量参数无效，「压到指定体积」只能靠缩尺寸，
       对噪点类图片几乎压不动。此时自动改用 JPEG 才可能命中目标。 */
    var note = '';
    if (opt.mode === 'size' && mime === 'image/png') {
      mime = 'image/jpeg';
      note = 'PNG 无法按体积压缩，已改用 JPG';
    }

    var iw = img.naturalWidth || img.width;
    var ih = img.naturalHeight || img.height;
    var scale = 1;
    if (opt.maxEdge && Math.max(iw, ih) > opt.maxEdge) scale = opt.maxEdge / Math.max(iw, ih);
    var w = Math.max(1, Math.round(iw * scale));
    var h = Math.max(1, Math.round(ih * scale));

    var canvas = drawTo(img, w, h, mime);
    loaded.revoke();

    var blob, quality = null;

    if (mime === 'image/png') {
      blob = await U.canvasToBlob(canvas, mime);
      note = 'PNG 为无损格式，体积由尺寸决定';
    } else if (opt.mode === 'size') {
      var target = Math.max(4 * 1024, opt.targetKB * 1024);
      var res = await bestQuality(canvas, mime, target);
      blob = res.blob;
      quality = res.quality;

      var round = 0;
      while (blob.size > target && round < 3) {
        round++;
        w = Math.max(1, Math.round(w * 0.85));
        h = Math.max(1, Math.round(h * 0.85));
        var smaller = drawTo(canvas, w, h, mime);
        var res2 = await bestQuality(smaller, mime, target);
        canvas = smaller;
        blob = res2.blob;
        quality = res2.quality;
      }
      var tailNote = blob.size > target
        ? '已缩到最小，仍略高于目标体积'
        : '目标 ' + opt.targetKB + 'KB，质量 ' + Math.round(quality * 100) + '%';
      note = note ? note + '；' + tailNote : tailNote;
    } else {
      blob = await U.canvasToBlob(canvas, mime, opt.quality);
      quality = opt.quality;
    }

    return {
      blob: blob,
      name: baseName(file.name) + '.min.' + EXT[mime],
      mime: mime,
      w: w,
      h: h,
      quality: quality,
      note: note,
      inSize: file.size,
      outSize: blob.size
    };
  }

  window.App.register({
    id: 'img-compress',
    cat: 'image',
    name: '图片压缩',
    icon: 'compress',
    desc: '批量压缩图片，可按质量或直接压到指定 KB',
    tags: ['压缩', '体积', 'kb', 'jpg', 'webp', '批量', 'compress', '上传'],
    mount: function (root) {
      root.innerHTML =
        '<div class="panel">' +
          '<div class="drop" id="drop">' +
            '<input type="file" id="picker" accept="image/*" multiple hidden />' +
            '<span class="drop-ico">' + icon('upload', 20) + '</span>' +
            '<div class="drop-txt"><b>点击选择图片</b><span>支持批量拖入，最多 20 张</span></div>' +
            '<div class="drop-meta" id="picked">未选择文件</div>' +
          '</div>' +

          '<div class="grid2" style="margin-top:14px">' +
            '<label class="field"><span>压缩方式</span>' +
              '<select class="control" id="mode">' +
                '<option value="quality">按质量压缩</option>' +
                '<option value="size">压到指定体积（KB）</option>' +
              '</select>' +
            '</label>' +
            '<label class="field"><span>输出格式</span>' +
              '<select class="control" id="format">' +
                '<option value="keep">保持原格式</option>' +
                '<option value="jpeg">JPG</option>' +
                '<option value="webp">WEBP</option>' +
                '<option value="png">PNG</option>' +
              '</select>' +
            '</label>' +
            '<label class="field" id="qualityField"><span>质量 <b class="val" id="qv">78</b>%</span>' +
              '<input type="range" id="q" min="20" max="100" step="1" value="78" />' +
            '</label>' +
            '<label class="field" id="sizeField" hidden><span>目标体积（KB）</span>' +
              '<input class="control" type="number" id="target" value="200" min="10" step="10" inputmode="numeric" />' +
            '</label>' +
            '<label class="field"><span>最长边限制（px，0 = 不缩放）</span>' +
              '<input class="control" type="number" id="maxedge" value="0" min="0" step="100" inputmode="numeric" />' +
            '</label>' +
            '<div class="field"><span>提示</span><div class="hint" id="tip">质量 70~85 通常肉眼无损</div></div>' +
          '</div>' +

          '<div class="actions">' +
            '<button class="btn primary" id="run" type="button">开始压缩</button>' +
            '<button class="btn" id="zip" type="button" hidden>打包下载 .zip</button>' +
            '<button class="btn ghost" id="reset" type="button">清空</button>' +
            '<span class="hint" id="status"></span>' +
          '</div>' +
        '</div>' +
        '<div class="results" id="out"></div>';

      var picker = $('#picker', root);
      var drop = $('#drop', root);
      var out = $('#out', root);
      var status = $('#status', root);
      var modeSel = $('#mode', root);
      var q = $('#q', root);
      var qv = $('#qv', root);
      var targetInput = $('#target', root);
      var fmt = $('#format', root);
      var maxEdge = $('#maxedge', root);
      var runBtn = $('#run', root);
      var zipBtn = $('#zip', root);

      var files = [];
      var results = [];
      var urls = [];
      var busy = false;

      function syncMode() {
        var bySize = modeSel.value === 'size';
        $('#qualityField', root).hidden = bySize;
        $('#sizeField', root).hidden = !bySize;
        $('#tip', root).textContent = bySize
          ? '自动二分搜索质量，必要时缩小尺寸以命中目标；PNG 是无损格式，无法按体积压缩时会自动改用 JPG'
          : '质量 70~85 通常肉眼无损';
      }

      modeSel.addEventListener('change', syncMode);
      q.addEventListener('input', function () { qv.textContent = q.value; });
      syncMode();

      function setFiles(list) {
        var imgs = Array.prototype.filter.call(list, function (f) { return /^image\//.test(f.type); });
        if (!imgs.length) { toast('请选择图片文件', 'err'); return; }
        files = imgs.slice(0, 20);
        var total = files.reduce(function (a, f) { return a + f.size; }, 0);
        $('#picked', root).innerHTML = files.length + ' 张 · ' + formatBytes(total);
        status.textContent = files.length > 20 ? '一次最多 20 张，已截取前 20 张' : '';
      }

      drop.addEventListener('click', function (e) { if (e.target !== picker) picker.click(); });
      ['dragenter', 'dragover'].forEach(function (ev) {
        drop.addEventListener(ev, function (e) { e.preventDefault(); drop.classList.add('dragover'); });
      });
      ['dragleave', 'drop'].forEach(function (ev) {
        drop.addEventListener(ev, function (e) { e.preventDefault(); drop.classList.remove('dragover'); });
      });
      drop.addEventListener('drop', function (e) {
        if (e.dataTransfer && e.dataTransfer.files) setFiles(e.dataTransfer.files);
      });
      picker.addEventListener('change', function () { setFiles(picker.files); });

      function clearResults() {
        urls.forEach(function (u) { URL.revokeObjectURL(u); });
        urls = [];
        results = [];
        out.innerHTML = '';
        zipBtn.hidden = true;
      }

      $('#reset', root).addEventListener('click', function () {
        files = [];
        picker.value = '';
        $('#picked', root).textContent = '未选择文件';
        status.textContent = '';
        clearResults();
      });

      function addRow(item) {
        var row = document.createElement('div');
        row.className = 'result';
        row.innerHTML =
          '<img class="thumb" alt="" src="' + item.thumbUrl + '" />' +
          '<div class="result-body">' +
            '<b>' + esc(item.name) + '</b>' +
            '<span>' + item.w + '×' + item.h + ' · ' + formatBytes(item.inSize) + ' → ' + formatBytes(item.outSize) +
            ' <b class="' + (item.outSize <= item.inSize ? 'badge-ok' : 'badge-bad') + '">' +
            (item.delta <= 0 ? '' : '+') + item.delta.toFixed(0) + '%</b>' +
            (item.note ? ' · ' + esc(item.note) : '') + '</span>' +
          '</div>' +
          '<button class="btn mini" type="button">下载</button>';
        row.querySelector('button').addEventListener('click', function () {
          U.download(item.blob, item.name);
        });
        out.appendChild(row);
      }

      runBtn.addEventListener('click', async function () {
        if (busy) return;
        if (!files.length) { toast('请先选择图片', 'err'); return; }

        busy = true;
        clearResults();
        runBtn.disabled = true;
        runBtn.textContent = '压缩中…';

        var opt = {
          mode: modeSel.value,
          format: fmt.value,
          quality: Number(q.value) / 100,
          targetKB: Math.max(10, Number(targetInput.value) || 200),
          maxEdge: Math.max(0, Number(maxEdge.value) || 0)
        };

        var before = 0, after = 0, ok = 0, failed = 0;

        for (var i = 0; i < files.length; i++) {
          status.textContent = '正在处理 ' + (i + 1) + '/' + files.length + '：' + files[i].name;
          try {
            var r = await compressOne(files[i], opt);
            var thumbUrl = URL.createObjectURL(r.blob);
            urls.push(thumbUrl);
            r.thumbUrl = thumbUrl;
            r.delta = files[i].size ? ((r.outSize - files[i].size) / files[i].size) * 100 : 0;
            before += files[i].size;
            after += r.outSize;
            ok++;
            results.push({ name: r.name, blob: r.blob });
            addRow(r);
          } catch (err) {
            failed++;
            var row = document.createElement('div');
            row.className = 'result';
            row.innerHTML = '<div class="result-body"><b>' + esc(files[i].name) + '</b>' +
              '<span style="color:var(--err)">压缩失败：' + esc(err.message) + '</span></div>';
            out.appendChild(row);
          }
        }

        busy = false;
        runBtn.disabled = false;
        runBtn.textContent = '开始压缩';
        zipBtn.hidden = results.length < 2;
        var delta = before ? ((after - before) / before) * 100 : 0;
        status.textContent = '完成 ' + ok + ' 张' + (failed ? '，失败 ' + failed + ' 张' : '') +
          ' · ' + formatBytes(before) + ' → ' + formatBytes(after) +
          '（省 ' + Math.max(0, -delta).toFixed(1) + '%）';
      });

      zipBtn.addEventListener('click', function () {
        if (!results.length) return;
        zipBtn.disabled = true;
        U.zipFiles(results).then(function (blob) {
          U.download(blob, 'compressed-images.zip');
          toast('已打包 ' + results.length + ' 张图片', 'ok');
        }).catch(function (e) {
          toast('打包失败：' + e.message, 'err');
        }).then(function () {
          zipBtn.disabled = false;
        });
      });
    }
  });
})();
