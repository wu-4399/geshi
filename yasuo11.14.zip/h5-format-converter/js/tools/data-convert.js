/* ==========================================================================
 * 工具：结构化数据互转（JSON / YAML / CSV / XML）
 * 内置轻量解析器：YAML 子集、CSV（含引号转义）、XML ↔ JS 对象
 * ========================================================================== */
(function () {
  'use strict';

  var U = window.U;
  var $ = U.$, icon = U.icon, toast = U.toast;

  /* ======================================================================
   * 一、YAML（子集：对象、数组、标量、行内 [] {}、块标量 | >）
   * ==================================================================== */

  function stripComment(s) {
    var q = null;
    for (var k = 0; k < s.length; k++) {
      var c = s.charAt(k);
      if (q) {
        if (c === q && s.charAt(k - 1) !== '\\') q = null;
      } else if (c === '"' || c === "'") {
        q = c;
      } else if (c === '#' && (k === 0 || /\s/.test(s.charAt(k - 1)))) {
        return s.slice(0, k).trim();
      }
    }
    return s.trim();
  }

  function splitKV(s) {
    var q = null;
    for (var k = 0; k < s.length; k++) {
      var c = s.charAt(k);
      if (q) {
        if (c === q) q = null;
        continue;
      }
      if (c === '"' || c === "'") { q = c; continue; }
      if (c === ':' && (k === s.length - 1 || /\s/.test(s.charAt(k + 1)))) {
        var key = s.slice(0, k).trim();
        if ((key.charAt(0) === '"' && key.slice(-1) === '"') || (key.charAt(0) === "'" && key.slice(-1) === "'")) {
          key = key.slice(1, -1);
        }
        return { key: key, val: s.slice(k + 1).trim() };
      }
    }
    return null;
  }

  function splitTopLevel(s) {
    var out = [], cur = '', depth = 0, q = null;
    for (var k = 0; k < s.length; k++) {
      var c = s.charAt(k);
      if (q) {
        cur += c;
        if (c === q) q = null;
        continue;
      }
      if (c === '"' || c === "'") { q = c; cur += c; continue; }
      if (c === '[' || c === '{') depth++;
      if (c === ']' || c === '}') depth--;
      if (c === ',' && depth === 0) { out.push(cur.trim()); cur = ''; continue; }
      cur += c;
    }
    if (cur.trim()) out.push(cur.trim());
    return out;
  }

  function parseScalar(s) {
    s = String(s).trim();
    if (!s) return null;
    if (s === '~' || /^null$/i.test(s)) return null;
    if (/^(true|false)$/i.test(s)) return s.toLowerCase() === 'true';
    if (/^-?\d+$/.test(s) && s.length < 16) return Number(s);
    if (/^-?(\d+\.\d*|\.\d+)([eE][-+]?\d+)?$/.test(s)) return Number(s);
    if (s.charAt(0) === '"' && s.slice(-1) === '"') {
      try { return JSON.parse(s); } catch (e) { return s.slice(1, -1); }
    }
    if (s.charAt(0) === "'" && s.slice(-1) === "'") return s.slice(1, -1).replace(/''/g, "'");
    if (s.charAt(0) === '[' && s.slice(-1) === ']') {
      var inner = s.slice(1, -1).trim();
      return inner ? splitTopLevel(inner).map(parseScalar) : [];
    }
    if (s.charAt(0) === '{' && s.slice(-1) === '}') {
      var body = s.slice(1, -1).trim();
      var obj = {};
      if (!body) return obj;
      splitTopLevel(body).forEach(function (pair) {
        var kv = splitKV(pair);
        if (kv) obj[kv.key] = parseScalar(kv.val);
        else if (pair) obj[pair] = null;
      });
      return obj;
    }
    return s;
  }

  function parseYAML(text) {
    var raw = String(text).replace(/\r\n?/g, '\n').split('\n');
    var lines = [];

    for (var n = 0; n < raw.length; n++) {
      var line = raw[n];
      if (!line.trim() || /^\s*#/.test(line)) continue;
      if (/^\s*(---|\.\.\.)\s*$/.test(line)) continue;
      if (/^%/.test(line)) continue;
      var indent = line.match(/^[ \t]*/)[0].replace(/\t/g, '  ').length;
      var content = stripComment(line.trim());
      if (!content) continue;
      lines.push({ indent: indent, content: content });
    }
    if (!lines.length) return null;

    var i = 0;

    function isListLine(c) { return c === '-' || c.indexOf('- ') === 0; }

    function nextBlock(baseIndent) {
      if (i < lines.length && lines[i].indent > baseIndent) return parseNode(lines[i].indent);
      return null;
    }

    function parseBlockScalar(val, baseIndent) {
      if (/^[|>][+-]?$/.test(val)) {
        var fold = val.charAt(0) === '>';
        var parts = [];
        while (i < lines.length && lines[i].indent > baseIndent) {
          parts.push(lines[i].content);
          i++;
        }
        return fold ? parts.join(' ') : parts.join('\n');
      }
      return parseScalar(val);
    }

    function parseNode(indent) {
      if (lines[i] && isListLine(lines[i].content)) return parseList(indent);
      return parseMap(indent);
    }

    function parseList(indent) {
      var arr = [];
      while (i < lines.length && lines[i].indent === indent && isListLine(lines[i].content)) {
        var baseIndent = lines[i].indent;
        var rest = lines[i].content.replace(/^-\s*/, '');
        if (!rest) {
          i++;
          arr.push(nextBlock(baseIndent));
          continue;
        }
        var kv = splitKV(rest);
        if (kv) {
          var map = {};
          i++;
          map[kv.key] = kv.val === '' ? nextBlock(baseIndent) : parseBlockScalar(kv.val, baseIndent);
          if (i < lines.length && lines[i].indent > indent && !isListLine(lines[i].content)) {
            var sub = parseMap(lines[i].indent);
            Object.keys(sub).forEach(function (k) { map[k] = sub[k]; });
          }
          arr.push(map);
        } else {
          i++;
          arr.push(parseBlockScalar(rest, baseIndent));
        }
      }
      return arr;
    }

    function parseMap(indent) {
      var obj = {};
      while (i < lines.length && lines[i].indent === indent && !isListLine(lines[i].content)) {
        var kv = splitKV(lines[i].content);
        if (!kv) { i++; continue; }
        i++;
        obj[kv.key] = kv.val === '' ? nextBlock(indent) : parseBlockScalar(kv.val, indent);
      }
      return obj;
    }

    var result = parseNode(lines[0].indent);
    return result;
  }

  function yamlString(s) {
    s = String(s);
    if (s === '') return '""';
    if (/^\s|\s$/.test(s)) return JSON.stringify(s);
    if (/^(true|false|null|~|-?\d+(\.\d+)?)$/i.test(s)) return JSON.stringify(s);
    if (/^[-?:,[\]{}#&*!|>'"%@`]/.test(s)) return JSON.stringify(s);
    if (/: | #/.test(s) || /[,[\]{}]/.test(s)) return JSON.stringify(s);
    return s;
  }

  function toYAML(value, indent) {
    indent = indent || 0;
    var pad = new Array(indent + 1).join('  ');

    if (value === null || value === undefined) return 'null';
    if (typeof value === 'boolean') return String(value);
    if (typeof value === 'number') return isFinite(value) ? String(value) : 'null';
    if (typeof value === 'string') {
      if (value.indexOf('\n') !== -1) {
        return '|-\n' + value.split('\n').map(function (l) { return pad + '  ' + l; }).join('\n');
      }
      return yamlString(value);
    }

    if (Array.isArray(value)) {
      if (!value.length) return '[]';
      return value.map(function (item) {
        if (item !== null && typeof item === 'object') {
          if (Array.isArray(item) && !item.length) return pad + '- []';
          if (!Array.isArray(item) && !Object.keys(item).length) return pad + '- {}';
          return pad + '- ' + toYAML(item, indent + 1).replace(/^ {2}/, '');
        }
        return pad + '- ' + toYAML(item, indent);
      }).join('\n');
    }

    var keys = Object.keys(value);
    if (!keys.length) return '{}';
    return keys.map(function (k) {
      var v = value[k];
      var key = yamlString(k);
      if (v !== null && typeof v === 'object') {
        if (Array.isArray(v) && !v.length) return pad + key + ': []';
        if (!Array.isArray(v) && !Object.keys(v).length) return pad + key + ': {}';
        return pad + key + ':\n' + toYAML(v, indent + 1);
      }
      if (typeof v === 'string' && v.indexOf('\n') !== -1) {
        return pad + key + ': |-\n' + v.split('\n').map(function (l) {
          return new Array(indent + 2).join('  ') + l;
        }).join('\n');
      }
      return pad + key + ': ' + toYAML(v, indent);
    }).join('\n');
  }

  /* ======================================================================
   * 二、CSV
   * ==================================================================== */

  function parseCSV(text) {
    text = String(text).replace(/^\uFEFF/, '');
    var firstLine = text.split('\n')[0] || '';
    var sep = (firstLine.split('\t').length - 1) > (firstLine.split(',').length - 1) ? '\t' : ',';

    var rows = [], row = [], field = '', inQ = false;
    for (var k = 0; k < text.length; k++) {
      var c = text.charAt(k);
      if (inQ) {
        if (c === '"') {
          if (text.charAt(k + 1) === '"') { field += '"'; k++; }
          else inQ = false;
        } else {
          field += c;
        }
      } else if (c === '"') {
        inQ = true;
      } else if (c === sep) {
        row.push(field); field = '';
      } else if (c === '\n') {
        row.push(field); rows.push(row); row = []; field = '';
      } else if (c !== '\r') {
        field += c;
      }
    }
    if (field !== '' || row.length) { row.push(field); rows.push(row); }

    return rows.filter(function (r) {
      return r.length > 1 || (r.length === 1 && String(r[0]).trim() !== '');
    });
  }

  function coerce(v) {
    if (v === undefined || v === null) return '';
    var s = String(v).trim();
    if (s === '') return '';
    if (/^(true|false)$/i.test(s)) return s.toLowerCase() === 'true';
    if (/^-?(0|[1-9]\d*)(\.\d+)?$/.test(s) && s.length < 16) return Number(s);
    return s;
  }

  function csvToValue(text) {
    var rows = parseCSV(text);
    if (!rows.length) return [];
    var seen = {};
    var headers = rows[0].map(function (h, idx) {
      var t = String(h).trim() || 'col' + (idx + 1);
      if (seen[t]) { seen[t]++; return t + '_' + seen[t]; }
      seen[t] = 1;
      return t;
    });
    var body = rows.slice(1).filter(function (r) {
      return r.some(function (c) { return String(c).trim() !== ''; });
    });
    if (!body.length) return [];
    return body.map(function (r) {
      var o = {};
      headers.forEach(function (h, idx) { o[h] = coerce(r[idx]); });
      return o;
    });
  }

  function toTable(value) {
    var headers = [], rows = [];

    if (Array.isArray(value)) {
      if (!value.length) return { headers: headers, rows: rows };
      var allObjects = value.every(function (v) { return v && typeof v === 'object' && !Array.isArray(v); });
      if (allObjects) {
        value.forEach(function (o) {
          Object.keys(o).forEach(function (k) { if (headers.indexOf(k) === -1) headers.push(k); });
        });
        rows = value.map(function (o) {
          return headers.map(function (h) {
            var v = o[h];
            if (v === undefined || v === null) return '';
            return typeof v === 'object' ? JSON.stringify(v) : v;
          });
        });
      } else {
        headers = ['value'];
        rows = value.map(function (v) {
          return [v !== null && typeof v === 'object' ? JSON.stringify(v) : (v === null ? '' : v)];
        });
      }
    } else if (value && typeof value === 'object') {
      headers = ['key', 'value'];
      rows = Object.keys(value).map(function (k) {
        var v = value[k];
        return [k, v !== null && typeof v === 'object' ? JSON.stringify(v) : (v === null ? '' : v)];
      });
    } else {
      headers = ['value'];
      rows = [[value === null || value === undefined ? '' : value]];
    }
    return { headers: headers, rows: rows };
  }

  function toCSV(value) {
    var t = toTable(value);
    if (!t.headers.length) return '';
    function cell(v) {
      var s = v === null || v === undefined ? '' : String(v);
      return /[",\n\r\t]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
    }
    var lines = [t.headers.map(cell).join(',')];
    t.rows.forEach(function (r) { lines.push(r.map(cell).join(',')); });
    return lines.join('\n');
  }

  /* ======================================================================
   * 三、XML
   * ==================================================================== */

  function nodeToValue(node) {
    var obj = {};
    if (node.attributes) {
      for (var a = 0; a < node.attributes.length; a++) {
        obj['@' + node.attributes[a].name] = node.attributes[a].value;
      }
    }

    var kids = [];
    for (var n = 0; n < node.childNodes.length; n++) {
      if (node.childNodes[n].nodeType === 1) kids.push(node.childNodes[n]);
    }

    var text = '';
    for (var t = 0; t < node.childNodes.length; t++) {
      if (node.childNodes[t].nodeType === 3) text += node.childNodes[t].nodeValue;
    }
    text = text.trim();

    if (!kids.length) {
      if (!Object.keys(obj).length) return text;
      if (text) obj['#text'] = text;
      return obj;
    }

    kids.forEach(function (kid) {
      var v = nodeToValue(kid);
      var name = kid.nodeName;
      if (Object.prototype.hasOwnProperty.call(obj, name)) {
        if (!Array.isArray(obj[name])) obj[name] = [obj[name]];
        obj[name].push(v);
      } else {
        obj[name] = v;
      }
    });
    if (text) obj['#text'] = text;
    return obj;
  }

  function xmlToValue(text) {
    var doc = new DOMParser().parseFromString(String(text), 'application/xml');
    var err = doc.getElementsByTagName('parsererror')[0];
    if (err) throw new Error('XML 解析失败：' + (err.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 120));
    if (!doc.documentElement) throw new Error('XML 没有根节点');
    var out = {};
    out[doc.documentElement.nodeName] = nodeToValue(doc.documentElement);
    return out;
  }

  function valueToXml(value, pretty) {
    var nl = pretty ? '\n' : '';
    function esc(s) {
      return String(s == null ? '' : s)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }
    function pad(d) { return pretty ? new Array(d + 1).join('  ') : ''; }

    function build(name, v, depth) {
      if (Array.isArray(v)) {
        return v.map(function (item) { return build(name, item, depth); }).join(nl);
      }
      if (v === null || v === undefined) return pad(depth) + '<' + name + '/>';
      if (typeof v !== 'object') return pad(depth) + '<' + name + '>' + esc(v) + '</' + name + '>';

      var attrs = Object.keys(v).filter(function (k) { return k.charAt(0) === '@'; })
        .map(function (k) { return ' ' + k.slice(1) + '="' + esc(v[k]) + '"'; }).join('');
      var kids = Object.keys(v).filter(function (k) { return k.charAt(0) !== '@' && k !== '#text'; });
      var text = v['#text'] !== undefined ? esc(v['#text']) : '';

      if (!kids.length) return pad(depth) + '<' + name + attrs + '>' + text + '</' + name + '>';
      var inner = kids.map(function (k) { return build(k, v[k], depth + 1); }).join(nl);
      return pad(depth) + '<' + name + attrs + '>' + nl + inner + nl + pad(depth) + '</' + name + '>';
    }

    var head = '<?xml version="1.0" encoding="UTF-8"?>' + nl;

    if (value && typeof value === 'object' && !Array.isArray(value)) {
      var keys = Object.keys(value).filter(function (k) { return k.charAt(0) !== '@' && k !== '#text'; });
      if (keys.length === 1) return head + build(keys[0], value[keys[0]], 0);
      if (!keys.length) return head + build('root', value, 0);
      return head + build('root', value, 0);
    }
    if (Array.isArray(value)) return head + build('root', value, 0);
    return head + build('root', value, 0);
  }

  /* ======================================================================
   * 四、格式注册表
   * ==================================================================== */

  var FORMATS = {
    json: {
      label: 'JSON',
      ext: 'json',
      mime: 'application/json',
      parse: function (t) { return JSON.parse(t); },
      stringify: function (v, pretty) { return JSON.stringify(v, null, pretty ? 2 : 0); }
    },
    yaml: {
      label: 'YAML',
      ext: 'yaml',
      mime: 'text/yaml',
      parse: parseYAML,
      stringify: function (v) { return toYAML(v); }
    },
    csv: {
      label: 'CSV',
      ext: 'csv',
      mime: 'text/csv',
      parse: csvToValue,
      stringify: toCSV
    },
    xml: {
      label: 'XML',
      ext: 'xml',
      mime: 'application/xml',
      parse: xmlToValue,
      stringify: function (v, pretty) { return valueToXml(v, pretty); }
    }
  };

  var SAMPLES = {
    json: '{\n  "name": "格式工坊",\n  "version": "1.0.0",\n  "tags": ["图片", "编码", "数据"],\n  "author": {\n    "name": "FormatLab",\n    "site": "https://example.com"\n  },\n  "stars": 128,\n  "active": true\n}',
    yaml: 'name: 格式工坊\nversion: 1.0.0\ntags:\n  - 图片\n  - 编码\n  - 数据\nauthor:\n  name: FormatLab\n  site: https://example.com\nstars: 128\nactive: true',
    csv: 'name,version,stars\n格式工坊,1.0.0,128\nFormatLab,1.0.0,256',
    xml: '<?xml version="1.0" encoding="UTF-8"?>\n<app>\n  <name>格式工坊</name>\n  <tags>\n    <tag>图片</tag>\n    <tag>编码</tag>\n  </tags>\n  <stars>128</stars>\n  <active>true</active>\n</app>'
  };

  /* 轻量 JSON 语法扫描：新版 Chrome 的 JSON.parse 报错已不带 position，
     这里自己走一遍语法，找出出错偏移量与原因，用于行列定位。 */
  function scanJSONError(text) {
    var i = 0;
    var len = text.length;

    function fail(msg) {
      var err = new Error(msg);
      err.at = i;
      throw err;
    }
    function ws() {
      while (i < len && (text[i] === ' ' || text[i] === '\t' || text[i] === '\n' || text[i] === '\r')) i++;
    }
    function parseValue() {
      ws();
      if (i >= len) fail('内容意外结束');
      var c = text[i];
      if (c === '{') return parseObject();
      if (c === '[') return parseArray();
      if (c === '"') return parseString();
      if (c === '-' || (c >= '0' && c <= '9')) return parseNumber();
      if (text.substr(i, 4) === 'true') { i += 4; return; }
      if (text.substr(i, 5) === 'false') { i += 5; return; }
      if (text.substr(i, 4) === 'null') { i += 4; return; }
      fail('这里不应该出现 ' + JSON.stringify(c));
    }
    function parseObject() {
      i++;
      ws();
      if (text[i] === '}') { i++; return; }
      while (true) {
        ws();
        if (text[i] !== '"') fail('对象的键必须是双引号字符串');
        parseString();
        ws();
        if (text[i] !== ':') fail('键值之间缺少冒号');
        i++;
        parseValue();
        ws();
        if (text[i] === ',') { i++; continue; }
        if (text[i] === '}') { i++; return; }
        fail('缺少逗号或右花括号');
      }
    }
    function parseArray() {
      i++;
      ws();
      if (text[i] === ']') { i++; return; }
      while (true) {
        parseValue();
        ws();
        if (text[i] === ',') { i++; continue; }
        if (text[i] === ']') { i++; return; }
        fail('缺少逗号或右方括号');
      }
    }
    function parseString() {
      i++;
      while (i < len) {
        var c = text[i];
        if (c === '"') { i++; return; }
        if (c === '\\') { i += 2; continue; }
        if (c === '\n') fail('字符串里出现了换行');
        i++;
      }
      fail('字符串没有闭合');
    }
    function parseNumber() {
      var start = i;
      if (text[i] === '-') i++;
      while (i < len && text[i] >= '0' && text[i] <= '9') i++;
      if (text[i] === '.') {
        i++;
        while (i < len && text[i] >= '0' && text[i] <= '9') i++;
      }
      if (text[i] === 'e' || text[i] === 'E') {
        i++;
        if (text[i] === '+' || text[i] === '-') i++;
        while (i < len && text[i] >= '0' && text[i] <= '9') i++;
      }
      if (i === start || (i === start + 1 && text[start] === '-')) fail('数字格式不完整');
    }

    try {
      parseValue();
      ws();
      if (i < len) fail('内容已结束，后面还有多余字符');
      return null;
    } catch (e) {
      if (e && typeof e.at === 'number') return { at: e.at, msg: e.message };
      throw e;
    }
  }

  function jsonError(e, text) {
    var pos = null;
    var detail = '';
    /* 优先用自带扫描器：文案统一，且不依赖浏览器错误消息格式 */
    var scanned = scanJSONError(text);
    if (scanned) {
      pos = scanned.at;
      detail = scanned.msg;
    } else {
      var m = /position (\d+)/.exec(e.message || '');
      if (m) pos = Number(m[1]);
    }
    if (pos === null) return e.message;
    var before = text.slice(0, pos);
    var line = before.split('\n').length;
    var col = pos - before.lastIndexOf('\n');
    return '第 ' + line + ' 行第 ' + col + ' 列附近有语法错误' + (detail ? '：' + detail : '');
  }

  /* 暴露只读解析器，方便控制台调试或单元测试 */
  window.FormatLabData = {
    parseYAML: parseYAML, toYAML: toYAML,
    parseCSV: parseCSV, csvToValue: csvToValue, toCSV: toCSV,
    xmlToValue: xmlToValue, valueToXml: valueToXml,
    FORMATS: FORMATS
  };

  /* ======================================================================
   * 五、界面
   * ==================================================================== */

  window.App.register({
    id: 'data-convert',
    cat: 'data',
    name: 'JSON / YAML / CSV / XML 互转',
    icon: 'braces',
    desc: '四种结构化数据任意互转，实时预览并定位语法错误',
    tags: ['json', 'yaml', 'yml', 'csv', 'xml', '数据', '格式化', '美化', '压缩'],
    mount: function (root) {
      var opts = Object.keys(FORMATS).map(function (k) {
        return '<option value="' + k + '">' + FORMATS[k].label + '</option>';
      }).join('');

      root.innerHTML =
        '<div class="panel">' +
          '<div class="conv-bar">' +
            '<label class="field"><span>源格式</span><select class="control" id="from">' + opts + '</select></label>' +
            '<button class="swap-btn" id="swap" type="button" title="交换源与目标">' + icon('swap', 17) + '</button>' +
            '<label class="field"><span>目标格式</span><select class="control" id="to">' +
              Object.keys(FORMATS).map(function (k) {
                return '<option value="' + k + '"' + (k === 'yaml' ? ' selected' : '') + '>' + FORMATS[k].label + '</option>';
              }).join('') +
            '</select></label>' +
          '</div>' +

          '<div class="editor-grid">' +
            '<div class="editor">' +
              '<div class="editor-head"><span>输入</span><span class="spacer"></span>' +
                '<button type="button" data-act="sample">示例</button>' +
                '<button type="button" data-act="clear">清空</button>' +
              '</div>' +
              '<textarea class="ta" id="src" spellcheck="false" placeholder="粘贴内容，自动实时转换…"></textarea>' +
            '</div>' +
            '<div class="editor">' +
              '<div class="editor-head"><span>输出</span><span class="spacer"></span>' +
                '<button type="button" data-act="copy">复制</button>' +
                '<button type="button" data-act="download">下载</button>' +
              '</div>' +
              '<textarea class="ta" id="dst" readonly spellcheck="false" placeholder="转换结果会实时出现在这里"></textarea>' +
            '</div>' +
          '</div>' +

          '<div class="err" id="err"></div>' +

          '<div class="actions">' +
            '<button class="btn primary" id="run" type="button">重新转换</button>' +
            '<button class="btn ghost" id="toggleP" type="button">压缩输出</button>' +
            '<span class="hint" id="stat">支持对象、数组、行内 [] 与 {}、以及 | 块文本</span>' +
          '</div>' +
        '</div>';

      var fromSel = $('#from', root);
      var toSel = $('#to', root);
      var src = $('#src', root);
      var dst = $('#dst', root);
      var errEl = $('#err', root);
      var stat = $('#stat', root);
      var pretty = true;

      function convert() {
        errEl.textContent = '';
        var text = src.value;
        if (!text.trim()) {
          dst.value = '';
          stat.textContent = '等待输入…';
          return;
        }
        var fromKey = fromSel.value;
        var toKey = toSel.value;
        try {
          var value = FORMATS[fromKey].parse(text);
          dst.value = FORMATS[toKey].stringify(value, pretty);
          stat.textContent = '✓ ' + FORMATS[fromKey].label + ' → ' + FORMATS[toKey].label +
            ' · ' + dst.value.length.toLocaleString() + ' 字符';
        } catch (e) {
          dst.value = '';
          stat.textContent = '';
          errEl.textContent = '⚠ ' + (fromKey === 'json' ? jsonError(e, text) : (e.message || '解析失败'));
        }
      }

      var live = U.debounce(convert, 320);
      src.addEventListener('input', live);
      fromSel.addEventListener('change', convert);
      toSel.addEventListener('change', convert);
      $('#run', root).addEventListener('click', convert);

      $('#swap', root).addEventListener('click', function () {
        var a = fromSel.value;
        fromSel.value = toSel.value;
        toSel.value = a;
        if (dst.value) src.value = dst.value;
        convert();
      });

      $('#toggleP', root).addEventListener('click', function () {
        pretty = !pretty;
        this.textContent = pretty ? '压缩输出' : '美化输出';
        convert();
      });

      U.$$('[data-act]', root).forEach(function (btn) {
        btn.addEventListener('click', function () {
          var act = btn.getAttribute('data-act');
          if (act === 'sample') {
            src.value = SAMPLES[fromSel.value];
            convert();
          } else if (act === 'clear') {
            src.value = '';
            dst.value = '';
            errEl.textContent = '';
            stat.textContent = '等待输入…';
          } else if (act === 'copy') {
            U.copy(dst.value);
          } else if (act === 'download') {
            if (!dst.value) return toast('还没有结果', 'err');
            var f = FORMATS[toSel.value];
            U.downloadText(dst.value, 'converted.' + f.ext, f.mime + ';charset=utf-8');
          }
        });
      });

      src.addEventListener('keydown', function (e) {
        if (e.key === 'Tab') {
          e.preventDefault();
          var s = this.selectionStart, en = this.selectionEnd;
          this.value = this.value.slice(0, s) + '  ' + this.value.slice(en);
          this.selectionStart = this.selectionEnd = s + 2;
        }
      });
    }
  });
})();
