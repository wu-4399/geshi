/* ==========================================================================
 * 工具：进制转换（2 / 8 / 10 / 16 及任意进制，支持任意大整数）
 * ========================================================================== */
(function () {
  'use strict';

  var U = window.U;
  var $ = U.$, toast = U.toast, esc = U.escapeHtml;

  var DIGITS = '0123456789abcdefghijklmnopqrstuvwxyz';

  function parseBig(str, base) {
    var s = String(str).trim().toLowerCase().replace(/[\s_,]/g, '');
    if (!s) throw new Error('请输入要转换的数字');

    var neg = false;
    if (s.charAt(0) === '-') { neg = true; s = s.slice(1); }
    else if (s.charAt(0) === '+') { s = s.slice(1); }

    var prefixes = { '0x': 16, '0b': 2, '0o': 8, '0d': 10 };
    Object.keys(prefixes).forEach(function (p) {
      if (s.indexOf(p) === 0) { base = prefixes[p]; s = s.slice(2); }
    });

    if (!s) throw new Error('请输入要转换的数字');
    if (base < 2 || base > 36) throw new Error('进制需在 2 ~ 36 之间');

    var big = 0n, B = BigInt(base);
    for (var i = 0; i < s.length; i++) {
      var d = DIGITS.indexOf(s.charAt(i));
      if (d < 0 || d >= base) {
        throw new Error('「' + s.charAt(i) + '」不是 ' + base + ' 进制中的有效数字');
      }
      big = big * B + BigInt(d);
    }
    return neg ? -big : big;
  }

  function groupBin(bin, size) {
    var out = '';
    for (var i = bin.length; i > 0; i -= size) {
      out = bin.slice(Math.max(0, i - size), i) + (out ? ' ' + out : '');
    }
    return out;
  }

  window.App.register({
    id: 'radix',
    cat: 'dev',
    name: '进制转换',
    icon: 'hash',
    desc: '二 / 八 / 十 / 十六进制互转，支持超大整数与位宽分析',
    tags: ['进制', '二进制', '十六进制', 'bit', 'byte', 'radix', 'bigint'],
    mount: function (root) {
      root.innerHTML =
        '<div class="panel">' +
          '<div class="grid2">' +
            '<label class="field"><span>数值（支持 0x / 0b / 0o 前缀）</span>' +
              '<input class="control" id="num" value="255" spellcheck="false" inputmode="text" />' +
            '</label>' +
            '<label class="field"><span>输入进制</span>' +
              '<select class="control" id="base">' +
                '<option value="10">十进制 (10)</option>' +
                '<option value="2">二进制 (2)</option>' +
                '<option value="8">八进制 (8)</option>' +
                '<option value="16">十六进制 (16)</option>' +
                '<option value="32">32 进制</option>' +
              '</select>' +
            '</label>' +
          '</div>' +
          '<div class="actions">' +
            '<span class="hint" id="hint">输入即转换，支持任意长度整数（BigInt）</span>' +
          '</div>' +
          '<div id="rows" class="rows"></div>' +
          '<div class="err" id="err"></div>' +
        '</div>';

      var input = $('#num', root);
      var baseSel = $('#base', root);
      var rowsEl = $('#rows', root);
      var errEl = $('#err', root);
      var values = [];

      rowsEl.addEventListener('click', function (e) {
        var btn = e.target.closest('[data-i]');
        if (!btn) return;
        U.copy(values[Number(btn.getAttribute('data-i'))]);
      });

      function update() {
        errEl.textContent = '';
        var base = Number(baseSel.value);
        var raw = input.value.trim();
        if (!raw) { rowsEl.innerHTML = ''; return; }

        var v;
        try {
          v = parseBig(raw, base);
        } catch (e) {
          rowsEl.innerHTML = '';
          errEl.textContent = '⚠ ' + e.message;
          return;
        }

        var abs = v < 0n ? -v : v;
        var bin = abs.toString(2);
        var bits = bin.length;
        var bytes = Math.ceil(bits / 8);
        var sign = v < 0n ? '-' : '';

        var list = [
          ['二进制', sign + groupBin(bin, 4)],
          ['八进制', sign + abs.toString(8)],
          ['十进制', v.toString(10)],
          ['十六进制', sign + abs.toString(16).toUpperCase()],
          ['0x 前缀', sign + '0x' + abs.toString(16).toUpperCase()],
          ['0b 前缀', sign + '0b' + bin],
          ['位宽', bits + ' bit'],
          ['字节', bytes + ' B']
        ];

        values = list.map(function (x) { return x[1]; });
        rowsEl.innerHTML = list.map(function (x, i) {
          return '<div class="kv"><span class="kv-k">' + esc(x[0]) + '</span>' +
            '<code class="kv-v">' + esc(x[1]) + '</code>' +
            '<button class="btn mini" type="button" data-i="' + i + '">复制</button></div>';
        }).join('');
      }

      input.addEventListener('input', update);
      baseSel.addEventListener('change', update);
      update();
    }
  });
})();
