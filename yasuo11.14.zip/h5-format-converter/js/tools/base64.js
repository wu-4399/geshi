/* ==========================================================================
 * 工具：文件 / 图片 ↔ Base64（Data URL）
 * ========================================================================== */
(function () {
  'use strict';

  var U = window.U;
  var $ = U.$, icon = U.icon, toast = U.toast, formatBytes = U.formatBytes, esc = U.escapeHtml;

  window.App.register({
    id: 'base64',
    cat: 'image',
    name: '文件 / 图片 ↔ Base64',
    icon: 'file',
    desc: '任意文件转 Data URL，或把 Base64 还原成可下载文件',
    tags: ['base64', 'dataurl', '图片', '文件', '编码', '内联'],
    mount: function (root) {
      root.innerHTML =
        '<div class="seg" id="tab">' +
          '<button class="seg-btn active" type="button" data-tab="enc">文件 → Base64</button>' +
          '<button class="seg-btn" type="button" data-tab="dec">Base64 → 文件</button>' +
        '</div>' +

        '<div class="panel" data-pane="enc">' +
          '<div class="drop" id="drop">' +
            '<input type="file" id="picker" hidden />' +
            '<span class="drop-ico">' + icon('upload', 20) + '</span>' +
            '<div class="drop-txt"><b>点击选择文件</b><span>图片、PDF、字体、压缩包… 任意类型</span></div>' +
            '<div class="drop-meta" id="info">未选择文件</div>' +
          '</div>' +
          '<div class="field" style="margin-top:14px">' +
            '<span>Data URL 输出</span>' +
            '<textarea class="ta" id="out" rows="7" readonly spellcheck="false" placeholder="选择文件后自动生成…"></textarea>' +
          '</div>' +
          '<div class="actions">' +
            '<button class="btn primary" id="copyBtn" type="button">复制</button>' +
            '<button class="btn" id="dlTxt" type="button">保存为 .txt</button>' +
            '<span class="hint" id="len"></span>' +
          '</div>' +
          '<div id="preview"></div>' +
        '</div>' +

        '<div class="panel" data-pane="dec" hidden>' +
          '<div class="field">' +
            '<span>粘贴 Base64 或 Data URL</span>' +
            '<textarea class="ta" id="src" rows="7" spellcheck="false" placeholder="data:image/png;base64,iVBORw0KGgo..."></textarea>' +
          '</div>' +
          '<div class="grid2" style="margin-top:12px">' +
            '<label class="field"><span>文件名（含扩展名）</span>' +
              '<input class="control" id="name" value="file" />' +
            '</label>' +
            '<label class="field"><span>识别到的类型</span>' +
              '<input class="control" id="type" readonly value="—" />' +
            '</label>' +
          '</div>' +
          '<div class="actions">' +
            '<button class="btn primary" id="decodeBtn" type="button">解析并下载</button>' +
            '<span class="hint" id="decInfo"></span>' +
          '</div>' +
          '<div id="decPreview"></div>' +
        '</div>';

      /* ---------------- 标签切换 ---------------- */
      U.$$('#tab .seg-btn', root).forEach(function (btn) {
        btn.addEventListener('click', function () {
          U.$$('#tab .seg-btn', root).forEach(function (b) { b.classList.remove('active'); });
          btn.classList.add('active');
          U.$$('[data-pane]', root).forEach(function (pane) {
            pane.hidden = pane.getAttribute('data-pane') !== btn.getAttribute('data-tab');
          });
        });
      });

      /* ---------------- 文件 → Base64 ---------------- */
      var picker = $('#picker', root);
      var drop = $('#drop', root);
      var out = $('#out', root);
      var preview = $('#preview', root);
      var current = null;

      drop.addEventListener('click', function (e) {
        if (e.target !== picker) picker.click();
      });
      ['dragenter', 'dragover'].forEach(function (ev) {
        drop.addEventListener(ev, function (e) { e.preventDefault(); drop.classList.add('dragover'); });
      });
      ['dragleave', 'drop'].forEach(function (ev) {
        drop.addEventListener(ev, function (e) { e.preventDefault(); drop.classList.remove('dragover'); });
      });
      drop.addEventListener('drop', function (e) {
        if (e.dataTransfer && e.dataTransfer.files[0]) handleFile(e.dataTransfer.files[0]);
      });
      picker.addEventListener('change', function () {
        if (picker.files[0]) handleFile(picker.files[0]);
      });

      function handleFile(file) {
        current = file;
        $('#info', root).innerHTML = esc(file.name) + ' · ' + formatBytes(file.size);
        preview.innerHTML = '';
        if (file.size > 20 * 1024 * 1024) {
          out.value = '';
          $('#len').textContent = '文件过大（>20MB），建议仅转换较小的资源';
          toast('文件超过 20MB，转换可能较慢', 'err');
        }
        U.blobToBase64(file).then(function (dataUrl) {
          out.value = dataUrl;
          $('#len').textContent = dataUrl.length.toLocaleString() + ' 字符 · 约 ' + formatBytes(dataUrl.length);
          if (/^data:image\//.test(dataUrl)) {
            var img = document.createElement('img');
            img.src = dataUrl;
            img.alt = '预览';
            img.style.cssText = 'max-width:100%;max-height:220px;border-radius:12px;border:1px solid var(--border);margin-top:14px';
            preview.appendChild(img);
          }
        }).catch(function (err) {
          toast(err.message, 'err');
        });
      }

      $('#copyBtn', root).addEventListener('click', function () { U.copy(out.value); });
      $('#dlTxt', root).addEventListener('click', function () {
        if (!out.value) return toast('还没有内容', 'err');
        U.downloadText(out.value, (current ? current.name : 'base64') + '.txt');
      });

      /* ---------------- Base64 → 文件 ---------------- */
      var src = $('#src', root);
      var nameInput = $('#name', root);
      var typeInput = $('#type', root);
      var decPreview = $('#decPreview', root);
      var decoded = null;

      function parse() {
        var raw = src.value.trim();
        if (!raw) { toast('请先粘贴 Base64 内容', 'err'); return; }
        try {
          var blob, mime;
          if (/^data:/i.test(raw)) {
            blob = U.dataURLToBlob(raw.replace(/\s/g, ''));
            mime = blob.type;
          } else {
            var clean = raw.replace(/\s/g, '');
            var bytes = U.base64ToBytes(clean);
            var head = new TextDecoder('utf-8', { fatal: false }).decode(bytes.slice(0, 16));
            mime = guessMime(bytes, head);
            blob = new Blob([bytes], { type: mime });
          }
          decoded = blob;
          typeInput.value = mime + ' · ' + formatBytes(blob.size);
          var ext = U.extFromMime(mime);
          if (!nameInput.value || nameInput.value === 'file' || !/\.[a-z0-9]+$/i.test(nameInput.value)) {
            nameInput.value = 'file.' + ext;
          }
          decPreview.innerHTML = '';
          if (/^image\//.test(mime)) {
            var url = URL.createObjectURL(blob);
            var img = document.createElement('img');
            img.src = url;
            img.alt = '预览';
            img.style.cssText = 'max-width:100%;max-height:240px;border-radius:12px;border:1px solid var(--border);margin-top:14px';
            decPreview.appendChild(img);
          }
          $('#decInfo', root).textContent = '解析成功，可下载';
          toast('解析成功', 'ok');
          return blob;
        } catch (e) {
          decoded = null;
          typeInput.value = '—';
          decPreview.innerHTML = '';
          $('#decInfo', root).textContent = '解析失败：' + e.message;
          toast('Base64 格式有误', 'err');
          return null;
        }
      }

      function guessMime(bytes, head) {
        if (bytes[0] === 0x89 && bytes[1] === 0x50) return 'image/png';
        if (bytes[0] === 0xff && bytes[1] === 0xd8) return 'image/jpeg';
        if (head.indexOf('GIF8') === 0) return 'image/gif';
        if (head.indexOf('RIFF') === 0 && head.indexOf('WEBP') > 0) return 'image/webp';
        if (head.indexOf('%PDF') === 0) return 'application/pdf';
        if (head.indexOf('PK') === 0) return 'application/zip';
        if (head.trim().indexOf('<svg') === 0 || head.indexOf('<?xml') === 0) return 'image/svg+xml';
        return 'application/octet-stream';
      }

      src.addEventListener('input', U.debounce(function () {
        if (src.value.trim()) parse();
      }, 420));

      $('#decodeBtn', root).addEventListener('click', function () {
        var blob = decoded || parse();
        if (!blob) return;
        var name = (nameInput.value || 'file').trim() || 'file';
        if (!/\.[a-z0-9]+$/i.test(name)) name += '.' + U.extFromMime(blob.type);
        U.download(blob, name);
      });
    }
  });
})();
