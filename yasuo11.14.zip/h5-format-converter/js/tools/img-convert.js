/* ==========================================================================
 * 工具：图片格式转换（PNG / JPG / WEBP）—— Canvas 重绘 + 质量 / 尺寸 / 背景色
 * ========================================================================== */
(function () {
  'use strict';

  var U = window.U;
  var $ = U.$, icon = U.icon, toast = U.toast, formatBytes = U.formatBytes, esc = U.escapeHtml;

  var EXT = { 'image/png': 'png', 'image/jpeg': 'jpg', 'image/webp': 'webp' };
  var MIME = {
    png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', webp: 'image/webp',
    gif: 'image/gif', bmp: 'image/bmp', svg: 'image/svg+xml', avif: 'image/avif'
  };

  function baseName(name) {
    return String(name || 'image').replace(/\.[^.]+$/, '') || 'image';
  }

  window.App.register({
    id: 'img-convert',
    cat: 'image',
    name: '图片格式转换',
    icon: 'image',
    desc: 'PNG / JPG / WEBP 互转，可调质量、尺寸与透明背景',
    tags: ['png', 'jpg', 'jpeg', 'webp', 'gif', 'bmp', 'svg', '压缩', '转换', 'image'],
    mount: function (root) {
      root.innerHTML =
        '<div class="panel">' +
          '<div class="drop" id="drop">' +
            '<input type="file" id="picker" accept="image/*" multiple hidden />' +
            '<span class="drop-ico">' + icon('upload', 20) + '</span>' +
            '<div class="drop-txt"><b>点击选择图片</b><span>也可以把图片拖进来 · 支持多选</span></div>' +
            '<div class="drop-meta" id="picked">未选择文件</div>' +
          '</div>' +
          '<div class="grid2" style="margin-top:14px">' +
            '<label class="field"><span>输出格式</span>' +
              '<select class="control" id="fmt">' +
                '<option value="image/png">PNG · 无损 / 支持透明</option>' +
                '<option value="image/jpeg">JPG · 体积小</option>' +
                '<option value="image/webp">WEBP · 体积更小</option>' +
              '</select>' +
            '</label>' +
            '<label class="field"><span>输出质量 <b class="val" id="qv">92</b>%</span>' +
              '<input type="range" id="q" min="30" max="100" step="1" value="92" />' +
            '</label>' +
            '<label class="field"><span>最大宽度（px，0 = 保持原尺寸）</span>' +
              '<input class="control" type="number" id="maxw" value="0" min="0" step="10" inputmode="numeric" />' +
            '</label>' +
            '<label class="field"><span>JPG 填充背景（透明区域）</span>' +
              '<input class="control" type="color" id="bg" value="#ffffff" />' +
            '</label>' +
          '</div>' +
          '<div class="actions">' +
            '<button class="btn primary" id="run" type="button">开始转换</button>' +
            '<button class="btn ghost" id="reset" type="button">清空列表</button>' +
            '<span class="hint" id="status">GIF 仅取第一帧，SVG 会按原始尺寸渲染</span>' +
          '</div>' +
        '</div>' +
        '<div class="results" id="out"></div>';

      var picker = $('#picker', root);
      var drop = $('#drop', root);
      var out = $('#out', root);
      var status = $('#status', root);
      var fmt = $('#fmt', root);
      var q = $('#q', root);
      var qv = $('#qv', root);
      var maxw = $('#maxw', root);
      var bg = $('#bg', root);
      var runBtn = $('#run', root);

      var files = [];
      var urls = [];

      function syncQualityState() {
        var lossy = fmt.value !== 'image/png';
        q.disabled = !lossy;
        bg.disabled = fmt.value !== 'image/jpeg';
        qv.textContent = q.value;
        q.style.opacity = lossy ? '1' : '0.45';
      }

      fmt.addEventListener('change', syncQualityState);
      q.addEventListener('input', function () { qv.textContent = q.value; });
      syncQualityState();

      function setFiles(list) {
        var imgs = Array.prototype.filter.call(list, function (f) {
          return /^image\//.test(f.type) || /\.(png|jpe?g|webp|gif|bmp|svg|avif)$/i.test(f.name);
        });
        if (!imgs.length) { toast('请选择图片文件', 'err'); return; }
        files = imgs.slice(0, 30);
        var total = files.reduce(function (a, f) { return a + f.size; }, 0);
        $('#picked', root).innerHTML = files.length + ' 张 · ' + formatBytes(total);
        status.textContent = files.length > 30 ? '一次最多处理 30 张，已截取前 30 张' : '准备就绪，点击开始转换';
      }

      drop.addEventListener('click', function (e) {
        if (e.target !== picker) picker.click();
      });
      drop.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); picker.click(); }
      });
      picker.addEventListener('change', function () { setFiles(picker.files); });

      ['dragenter', 'dragover'].forEach(function (ev) {
        drop.addEventListener(ev, function (e) {
          e.preventDefault();
          drop.classList.add('dragover');
        });
      });
      ['dragleave', 'drop'].forEach(function (ev) {
        drop.addEventListener(ev, function (e) {
          e.preventDefault();
          drop.classList.remove('dragover');
        });
      });
      drop.addEventListener('drop', function (e) {
        if (e.dataTransfer && e.dataTransfer.files) setFiles(e.dataTransfer.files);
      });

      function clearResults() {
        urls.forEach(function (u) { URL.revokeObjectURL(u); });
        urls = [];
        out.innerHTML = '';
      }

      $('#reset', root).addEventListener('click', function () {
        files = [];
        picker.value = '';
        $('#picked', root).textContent = '未选择文件';
        clearResults();
        status.textContent = 'GIF 仅取第一帧，SVG 会按原始尺寸渲染';
      });

      function renderResult(item) {
        var el = document.createElement('div');
        el.className = 'result';
        el.innerHTML =
          '<img class="thumb" alt="" src="' + item.thumbUrl + '" />' +
          '<div class="result-body">' +
            '<b>' + esc(item.name) + '</b>' +
            '<span>' + item.dims + ' · ' + formatBytes(item.inSize) + ' → ' + formatBytes(item.outSize) +
            ' <b class="' + (item.delta <= 0 ? 'badge-ok' : 'badge-bad') + '">' +
            (item.delta <= 0 ? '' : '+') + item.delta.toFixed(0) + '%</b></span>' +
          '</div>' +
          '<button class="btn mini" type="button">下载</button>';
        el.querySelector('button').addEventListener('click', function () {
          U.download(item.blob, item.name);
        });
        out.appendChild(el);
      }

      runBtn.addEventListener('click', async function () {
        if (!files.length) { toast('请先选择图片', 'err'); return; }
        var targetMime = fmt.value;
        var quality = Math.min(1, Math.max(0.1, Number(q.value) / 100));
        var limitW = Math.max(0, Number(maxw.value) || 0);
        var bgColor = bg.value;

        clearResults();
        runBtn.disabled = true;
        runBtn.textContent = '转换中…';
        var before = 0, after = 0, ok = 0, failed = 0;

        for (var i = 0; i < files.length; i++) {
          var file = files[i];
          status.textContent = '正在处理 ' + (i + 1) + '/' + files.length + '：' + file.name;
          try {
            var loaded = await U.loadImage(file);
            var img = loaded.img;
            var w = img.naturalWidth || img.width;
            var h = img.naturalHeight || img.height;
            if (!w || !h) throw new Error('图片尺寸无效');
            if (limitW && w > limitW) {
              h = Math.max(1, Math.round(h * limitW / w));
              w = limitW;
            }
            var canvas = document.createElement('canvas');
            canvas.width = w;
            canvas.height = h;
            var ctx = canvas.getContext('2d');
            ctx.imageSmoothingEnabled = true;
            ctx.imageSmoothingQuality = 'high';
            if (targetMime === 'image/jpeg') {
              ctx.fillStyle = bgColor;
              ctx.fillRect(0, 0, w, h);
            }
            ctx.drawImage(img, 0, 0, w, h);
            loaded.revoke();

            var blob = await U.canvasToBlob(canvas, targetMime, quality);
            if (blob.type && blob.type !== targetMime) {
              toast('浏览器不支持 ' + EXT[targetMime].toUpperCase() + '，已自动回退', 'err');
            }

            var thumbUrl = URL.createObjectURL(blob);
            urls.push(thumbUrl);
            before += file.size;
            after += blob.size;
            ok++;
            renderResult({
              name: baseName(file.name) + '.' + EXT[targetMime],
              blob: blob,
              thumbUrl: thumbUrl,
              dims: w + '×' + h,
              inSize: file.size,
              outSize: blob.size,
              delta: file.size ? ((blob.size - file.size) / file.size) * 100 : 0
            });
          } catch (err) {
            failed++;
            var row = document.createElement('div');
            row.className = 'result';
            row.innerHTML =
              '<div class="result-body"><b>' + esc(file.name) + '</b>' +
              '<span style="color:var(--err)">转换失败：' + esc(err.message) + '</span></div>';
            out.appendChild(row);
          }
        }

        runBtn.disabled = false;
        runBtn.textContent = '开始转换';
        var delta = before ? ((after - before) / before) * 100 : 0;
        status.textContent = '完成 ' + ok + ' 张' + (failed ? '，失败 ' + failed + ' 张' : '') +
          ' · 总体积 ' + formatBytes(before) + ' → ' + formatBytes(after) +
          '（' + (delta <= 0 ? '' : '+') + delta.toFixed(1) + '%）';
      });
    }
  });
})();
