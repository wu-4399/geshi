/* ==========================================================================
 * 工具：证件照换底色
 * 纯前端色差抠像：边缘取色 → 容差判定 → 羽化过渡 → 合成新底色
 * 附带标准证件照尺寸（300dpi）与人物垂直位置微调
 * ========================================================================== */
(function () {
  'use strict';

  var U = window.U;
  var $ = U.$, icon = U.icon, toast = U.toast, esc = U.escapeHtml, formatBytes = U.formatBytes;

  var SIZES = [
    { id: 'one', name: '一寸 25×35mm', w: 295, h: 413 },
    { id: 'small1', name: '小一寸 22×32mm', w: 260, h: 378 },
    { id: 'big1', name: '大一寸 33×48mm', w: 390, h: 567 },
    { id: 'two', name: '二寸 35×49mm', w: 413, h: 579 },
    { id: 'small2', name: '小二寸 35×45mm', w: 413, h: 531 },
    { id: 'passport', name: '护照 33×48mm', w: 390, h: 567 },
    { id: 'orig', name: '原始比例（最长边 1200px）', w: 0, h: 0 }
  ];

  var PRESETS = [
    { c: '#FFFFFF', name: '白底' },
    { c: '#438EDB', name: '蓝底' },
    { c: '#D9001B', name: '红底' },
    { c: '#1A4B8C', name: '深蓝' },
    { c: '#E6E8EB', name: '浅灰' },
    { c: '#2E7D5B', name: '绿底' }
  ];

  function hexToRgb(hex) {
    var h = String(hex).replace('#', '');
    if (h.length === 3) h = h.split('').map(function (c) { return c + c; }).join('');
    return {
      r: parseInt(h.slice(0, 2), 16) || 0,
      g: parseInt(h.slice(2, 4), 16) || 0,
      b: parseInt(h.slice(4, 6), 16) || 0
    };
  }

  function rgbToHex(c) {
    function p(n) { return Math.max(0, Math.min(255, Math.round(n))).toString(16).padStart(2, '0'); }
    return '#' + p(c.r) + p(c.g) + p(c.b);
  }

  /* 从画面边缘取出现最多的颜色作为背景色 */
  function detectKeyColor(img) {
    var max = 220;
    var iw = img.naturalWidth || img.width;
    var ih = img.naturalHeight || img.height;
    var k = Math.min(1, max / Math.max(iw, ih));
    var w = Math.max(1, Math.round(iw * k));
    var h = Math.max(1, Math.round(ih * k));
    var c = document.createElement('canvas');
    c.width = w;
    c.height = h;
    var ctx = c.getContext('2d');
    ctx.drawImage(img, 0, 0, w, h);
    var d = ctx.getImageData(0, 0, w, h).data;
    var band = Math.max(2, Math.round(Math.min(w, h) * 0.06));
    var buckets = {};

    for (var y = 0; y < h; y++) {
      for (var x = 0; x < w; x++) {
        if (!(x < band || y < band || x >= w - band || y >= h - band)) continue;
        var i = (y * w + x) * 4;
        var key = (d[i] >> 4) + ',' + (d[i + 1] >> 4) + ',' + (d[i + 2] >> 4);
        var b = buckets[key] || (buckets[key] = { n: 0, r: 0, g: 0, b: 0 });
        b.n++;
        b.r += d[i];
        b.g += d[i + 1];
        b.b += d[i + 2];
      }
    }

    var best = null;
    Object.keys(buckets).forEach(function (k2) {
      if (!best || buckets[k2].n > best.n) best = buckets[k2];
    });
    if (!best) return { r: 255, g: 255, b: 255 };
    return { r: Math.round(best.r / best.n), g: Math.round(best.g / best.n), b: Math.round(best.b / best.n) };
  }

  function replaceBg(imageData, o) {
    var px = imageData.data;
    var key = o.key;
    var bg = o.bgRGB;
    var tol = o.tol * 4.42;
    var feather = o.feather * 4.42;
    var keep = o.transparent;

    for (var i = 0; i < px.length; i += 4) {
      var r = px[i], g = px[i + 1], b = px[i + 2];
      var dr = r - key.r, dg = g - key.g, db = b - key.b;
      var dist = Math.sqrt(dr * dr + dg * dg + db * db);

      if (dist <= tol) {
        if (keep) {
          px[i + 3] = 0;
        } else {
          px[i] = bg.r; px[i + 1] = bg.g; px[i + 2] = bg.b; px[i + 3] = 255;
        }
      } else if (feather > 0 && dist < tol + feather) {
        var a = (dist - tol) / feather;   // 0 = 背景, 1 = 人物
        if (keep) {
          px[i + 3] = Math.round(px[i + 3] * a);
        } else {
          px[i] = Math.round(r * a + bg.r * (1 - a));
          px[i + 1] = Math.round(g * a + bg.g * (1 - a));
          px[i + 2] = Math.round(b * a + bg.b * (1 - a));
          px[i + 3] = 255;
        }
      }
    }
  }

  /* 按目标尺寸 cover 裁切绘制，offset: -100~100 控制垂直位置 */
  function render(canvas, img, o) {
    var W = o.w, H = o.h;
    canvas.width = W;
    canvas.height = H;
    var ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, W, H);

    var iw = img.naturalWidth || img.width;
    var ih = img.naturalHeight || img.height;
    var scale = Math.max(W / iw, H / ih);
    var dw = iw * scale;
    var dh = ih * scale;
    var dx = (W - dw) / 2;
    var dy = (H - dh) * (0.5 + (o.offset || 0) / 200);

    if (!o.transparent) {
      ctx.fillStyle = o.bg;
      ctx.fillRect(0, 0, W, H);
    }
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(img, dx, dy, dw, dh);

    var data = ctx.getImageData(0, 0, W, H);
    if (o.apply && o.key) {
      replaceBg(data, o);
      ctx.putImageData(data, 0, 0);
    }
    return data;
  }

  window.App.register({
    id: 'id-photo',
    cat: 'image',
    name: '证件照换底色',
    icon: 'user',
    desc: '一键替换白 / 蓝 / 红底，输出标准尺寸证件照',
    tags: ['证件照', '换底色', '一寸', '二寸', '白底', '蓝底', '红底', '1寸', 'id photo'],
    mount: function (root) {
      var sizeOptions = SIZES.map(function (s) {
        return '<option value="' + s.id + '">' + s.name + '</option>';
      }).join('');

      var swatches = PRESETS.map(function (p, i) {
        return '<button class="sw' + (i === 1 ? ' active' : '') + '" type="button" data-c="' + p.c + '">' +
          '<i style="background:' + p.c + '"></i><span>' + p.name + '</span></button>';
      }).join('');

      root.innerHTML =
        '<div class="panel">' +
          '<div class="drop" id="drop">' +
            '<input type="file" id="picker" accept="image/*" hidden />' +
            '<span class="drop-ico">' + icon('user', 20) + '</span>' +
            '<div class="drop-txt"><b>点击选择人像照片</b><span>纯色背景（白 / 蓝 / 红）效果最好，正面免冠照</span></div>' +
            '<div class="drop-meta" id="info">未选择照片</div>' +
          '</div>' +

          '<div id="studio" hidden>' +
            '<div class="idphoto">' +
              '<div class="idphoto-preview">' +
                '<div class="canvas-holder"><canvas id="prev"></canvas></div>' +
                '<p class="hint" id="hint">点击画面可吸取该处颜色作为背景</p>' +
              '</div>' +

              '<div class="idphoto-panel">' +
                '<div class="field">' +
                  '<span>新底色</span>' +
                  '<div class="swatches" id="swatches">' + swatches + '</div>' +
                '</div>' +

                '<label class="field" style="margin-top:12px">' +
                  '<span>自定义底色</span>' +
                  '<input class="control" type="color" id="custom" value="#438edb" />' +
                '</label>' +

                '<label class="field" style="margin-top:12px">' +
                  '<span>容差 <b class="val" id="tolv">16</b>（抠图范围）</span>' +
                  '<input type="range" id="tol" min="2" max="60" step="1" value="16" />' +
                '</label>' +

                '<label class="field">' +
                  '<span>边缘羽化 <b class="val" id="fv">10</b></span>' +
                  '<input type="range" id="feather" min="0" max="40" step="1" value="10" />' +
                '</label>' +

                '<label class="field" style="margin-top:12px">' +
                  '<span>尺寸规格</span>' +
                  '<select class="control" id="size">' + sizeOptions + '</select>' +
                '</label>' +

                '<label class="field">' +
                  '<span>垂直位置 <b class="val" id="ovy">0</b></span>' +
                  '<input type="range" id="offset" min="-50" max="50" step="1" value="0" />' +
                '</label>' +

                '<label class="check" style="margin-top:12px">' +
                  '<input type="checkbox" id="trans" /> <span>透明背景（导出 PNG）</span>' +
                '</label>' +

                '<div class="actions">' +
                  '<button class="btn primary" id="dl" type="button">下载证件照</button>' +
                  '<button class="btn ghost" id="compare" type="button">对比原图</button>' +
                '</div>' +
                '<p class="hint" id="meta" style="margin-top:8px"></p>' +
              '</div>' +
            '</div>' +
          '</div>' +
        '</div>';

      var picker = $('#picker', root);
      var drop = $('#drop', root);
      var studio = $('#studio', root);
      var canvas = $('#prev', root);
      var hint = $('#hint', root);
      var meta = $('#meta', root);
      var sizeSel = $('#size', root);
      var tol = $('#tol', root);
      var tolV = $('#tolv', root);
      var feather = $('#feather', root);
      var fV = $('#fv', root);
      var offset = $('#offset', root);
      var oVy = $('#ovy', root);
      var custom = $('#custom', root);
      var trans = $('#trans', root);
      var compareBtn = $('#compare', root);
      var dlBtn = $('#dl', root);

      var state = {
        img: null,
        file: null,
        key: { r: 255, g: 255, b: 255 },
        bg: '#438EDB',
        offset: 0,
        compare: false,
        baseData: null
      };

      function targetSize() {
        var s = SIZES.filter(function (x) { return x.id === sizeSel.value; })[0] || SIZES[0];
        if (s.w) return { w: s.w, h: s.h, label: s.name };
        var iw = state.img.naturalWidth, ih = state.img.naturalHeight;
        var k = Math.min(1, 1200 / Math.max(iw, ih));
        return { w: Math.max(1, Math.round(iw * k)), h: Math.max(1, Math.round(ih * k)), label: '原始比例' };
      }

      function draw() {
        if (!state.img) return;
        var t = targetSize();
        var isTrans = trans.checked;
        var data = render(canvas, state.img, {
          w: t.w,
          h: t.h,
          offset: state.offset,
          key: state.key,
          tol: Number(tol.value),
          feather: Number(feather.value),
          bg: state.bg,
          bgRGB: hexToRgb(state.bg),
          transparent: isTrans,
          apply: !state.compare
        });
        state.baseData = data;
        meta.textContent = t.label + ' · ' + t.w + '×' + t.h + 'px' +
          (isTrans ? ' · PNG 透明背景' : ' · JPG');
        hint.textContent = state.compare
          ? '当前显示原图（未换底色）'
          : '点击画面可吸取该处颜色作为背景';
      }

      var pending = false;
      function schedule() {
        if (pending) return;
        pending = true;
        requestAnimationFrame(function () { pending = false; draw(); });
      }

      function setFile(file) {
        if (!file) return;
        U.loadImage(file).then(function (loaded) {
          state.img = loaded.img;
          state.file = file;
          loaded.revoke();
          state.key = detectKeyColor(state.img);
          studio.hidden = false;
          $('#info', root).innerHTML = esc(file.name) + ' · ' +
            state.img.naturalWidth + '×' + state.img.naturalHeight + ' · ' + formatBytes(file.size);
          draw();
          toast('已识别背景色 ' + rgbToHex(state.key) + '，可微调容差', 'ok');
        }).catch(function (e) {
          toast(e.message, 'err');
        });
      }

      drop.addEventListener('click', function (e) { if (e.target !== picker) picker.click(); });
      ['dragenter', 'dragover'].forEach(function (ev) {
        drop.addEventListener(ev, function (e) { e.preventDefault(); drop.classList.add('dragover'); });
      });
      ['dragleave', 'drop'].forEach(function (ev) {
        drop.addEventListener(ev, function (e) { e.preventDefault(); drop.classList.remove('dragover'); });
      });
      drop.addEventListener('drop', function (e) {
        if (e.dataTransfer && e.dataTransfer.files[0]) setFile(e.dataTransfer.files[0]);
      });
      picker.addEventListener('change', function () { setFile(picker.files[0]); });

      /* 取色 */
      canvas.addEventListener('click', function (e) {
        if (!state.baseData) return;
        var rect = canvas.getBoundingClientRect();
        var x = Math.floor((e.clientX - rect.left) * canvas.width / rect.width);
        var y = Math.floor((e.clientY - rect.top) * canvas.height / rect.height);
        x = Math.max(0, Math.min(canvas.width - 1, x));
        y = Math.max(0, Math.min(canvas.height - 1, y));
        var i = (y * canvas.width + x) * 4;
        var d = state.baseData.data;
        state.key = { r: d[i], g: d[i + 1], b: d[i + 2] };
        state.compare = false;
        compareBtn.textContent = '对比原图';
        draw();
        toast('已吸取背景色 ' + rgbToHex(state.key));
      });

      /* 底色 */
      U.$$('.sw', root).forEach(function (btn) {
        btn.addEventListener('click', function () {
          U.$$('.sw', root).forEach(function (b) { b.classList.remove('active'); });
          btn.classList.add('active');
          state.bg = btn.getAttribute('data-c');
          custom.value = state.bg;
          draw();
        });
      });

      custom.addEventListener('input', function () {
        state.bg = custom.value;
        U.$$('.sw', root).forEach(function (b) { b.classList.remove('active'); });
        draw();
      });

      tol.addEventListener('input', function () { tolV.textContent = tol.value; schedule(); });
      feather.addEventListener('input', function () { fV.textContent = feather.value; schedule(); });
      offset.addEventListener('input', function () { oVy.textContent = offset.value; state.offset = Number(offset.value); schedule(); });
      sizeSel.addEventListener('change', draw);
      trans.addEventListener('change', draw);

      compareBtn.addEventListener('click', function () {
        state.compare = !state.compare;
        compareBtn.textContent = state.compare ? '看换底效果' : '对比原图';
        draw();
      });

      dlBtn.addEventListener('click', async function () {
        if (!state.img) return toast('请先选择照片', 'err');
        var t = targetSize();
        var isTrans = trans.checked;
        var off = document.createElement('canvas');
        render(off, state.img, {
          w: t.w,
          h: t.h,
          offset: state.offset,
          key: state.key,
          tol: Number(tol.value),
          feather: Number(feather.value),
          bg: state.bg,
          bgRGB: hexToRgb(state.bg),
          transparent: isTrans,
          apply: true
        });
        try {
          var mime = isTrans ? 'image/png' : 'image/jpeg';
          var blob = await U.canvasToBlob(off, mime, 0.95);
          var preset = PRESETS.filter(function (p) { return p.c.toLowerCase() === state.bg.toLowerCase(); })[0];
          var name = '证件照-' + t.label.split(' ')[0] + '-' + (isTrans ? '透明' : (preset ? preset.name : rgbToHex(state.bg))) + '.' + (isTrans ? 'png' : 'jpg');
          U.download(blob, name);
          toast('已导出 ' + t.w + '×' + t.h + ' 证件照', 'ok');
        } catch (e) {
          toast('导出失败：' + e.message, 'err');
        }
      });
    }
  });
})();
