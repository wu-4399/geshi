/* ==========================================================================
 * 工具：文本编码转换（Base64 / URL / Hex / Unicode / HTML 实体 / 二进制）
 * ========================================================================== */
(function () {
  'use strict';

  var U = window.U;
  var $ = U.$, toast = U.toast;

  function toBytes(str) { return new TextEncoder().encode(str); }
  function fromBytes(bytes) { return new TextDecoder().decode(bytes); }

  function htmlDecode(str) {
    var d = document.createElement('textarea');
    d.innerHTML = str;
    return d.value;
  }

  var MODES = {
    base64: {
      label: 'Base64',
      tip: '常用于把二进制嵌入文本、HTTP 传输',
      encode: function (s) { return U.textToBase64(s); },
      decode: function (s) { return U.base64ToText(s.replace(/\s+/g, '')); }
    },
    base64url: {
      label: 'Base64 URL 安全',
      tip: '把 + / 换成 - _，去掉末尾 =，用于 URL 与 JWT',
      encode: function (s) {
        return U.textToBase64(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
      },
      decode: function (s) {
        var t = s.replace(/\s+/g, '').replace(/-/g, '+').replace(/_/g, '/');
        while (t.length % 4) t += '=';
        return U.base64ToText(t);
      }
    },
    url: {
      label: 'URL 编码（Percent）',
      tip: '对 URL 中的特殊字符做百分号转义',
      encode: function (s) { return encodeURIComponent(s); },
      decode: function (s) { return decodeURIComponent(s); }
    },
    hex: {
      label: 'Hex 十六进制',
      tip: 'UTF-8 字节的十六进制表示，每字节两位',
      encode: function (s) {
        return Array.prototype.map.call(toBytes(s), function (b) {
          return b.toString(16).padStart(2, '0');
        }).join(' ');
      },
      decode: function (s) {
        var hex = s.replace(/0x/gi, '').replace(/[^0-9a-f]/gi, '');
        if (hex.length % 2) throw new Error('Hex 字符个数应为偶数');
        var bytes = new Uint8Array(hex.length / 2);
        for (var i = 0; i < bytes.length; i++) bytes[i] = parseInt(hex.substr(i * 2, 2), 16);
        return fromBytes(bytes);
      }
    },
    unicode: {
      label: 'Unicode 转义',
      tip: '非 ASCII 字符转成 \\uXXXX，适合写进源码字符串',
      encode: function (s) {
        return Array.from(s).map(function (ch) {
          var cp = ch.codePointAt(0);
          if (cp < 0x80) return ch;
          if (cp > 0xffff) return '\\u{' + cp.toString(16) + '}';
          return '\\u' + cp.toString(16).padStart(4, '0');
        }).join('');
      },
      decode: function (s) {
        return s.replace(/\\u\{([0-9a-fA-F]+)\}|\\u([0-9a-fA-F]{4})/g, function (m, a, b) {
          return String.fromCodePoint(parseInt(a || b, 16));
        });
      }
    },
    html: {
      label: 'HTML 实体',
      tip: '把 & < > 与中文等字符转成字符实体',
      encode: function (s) {
        return Array.from(s).map(function (ch) {
          if (ch === '&') return '&amp;';
          if (ch === '<') return '&lt;';
          if (ch === '>') return '&gt;';
          if (ch === '"') return '&quot;';
          if (ch === "'") return '&#39;';
          if (ch.codePointAt(0) > 126) return '&#' + ch.codePointAt(0) + ';';
          return ch;
        }).join('');
      },
      decode: function (s) { return htmlDecode(s); }
    },
    binary: {
      label: '二进制（0/1）',
      tip: '每字节 8 位，适合观察底层数据结构',
      encode: function (s) {
        return Array.prototype.map.call(toBytes(s), function (b) {
          return b.toString(2).padStart(8, '0');
        }).join(' ');
      },
      decode: function (s) {
        var bin = s.replace(/[^01]/g, '');
        if (!bin.length) return '';
        if (bin.length % 8) throw new Error('二进制位数应为 8 的整数倍');
        var bytes = new Uint8Array(bin.length / 8);
        for (var i = 0; i < bytes.length; i++) bytes[i] = parseInt(bin.substr(i * 8, 8), 2);
        return fromBytes(bytes);
      }
    }
  };

  window.App.register({
    id: 'text-encode',
    cat: 'text',
    name: '文本编码转换',
    icon: 'code',
    desc: 'Base64、URL、Hex、Unicode、HTML 实体、二进制互转',
    tags: ['base64', 'url', 'hex', 'unicode', 'html', 'binary', '编码', '解码', '转义'],
    mount: function (root) {
      root.innerHTML =
        '<div class="panel">' +
          '<label class="field">' +
            '<span>编码方式</span>' +
            '<select class="control" id="mode">' +
              Object.keys(MODES).map(function (k) {
                return '<option value="' + k + '">' + MODES[k].label + '</option>';
              }).join('') +
            '</select>' +
          '</label>' +
          '<p class="hint" id="tip" style="margin:8px 0 0">' + MODES.base64.tip + '</p>' +

          '<div class="field" style="margin-top:14px">' +
            '<span>输入</span>' +
            '<textarea class="ta" id="src" rows="6" spellcheck="false" placeholder="在这里输入要转换的文本…"></textarea>' +
          '</div>' +

          '<div class="actions">' +
            '<button class="btn primary" id="enc" type="button">编码 →</button>' +
            '<button class="btn" id="dec" type="button">← 解码</button>' +
            '<button class="btn ghost" id="swap" type="button">结果换到输入</button>' +
            '<button class="btn ghost" id="clear" type="button">清空</button>' +
            '<span class="hint" id="stat"></span>' +
          '</div>' +

          '<div class="field" style="margin-top:14px">' +
            '<span>输出</span>' +
            '<textarea class="ta" id="dst" rows="6" readonly spellcheck="false" placeholder="结果会显示在这里…"></textarea>' +
          '</div>' +

          '<div class="actions">' +
            '<button class="btn" id="copy" type="button">复制结果</button>' +
            '<button class="btn ghost" id="download" type="button">下载 .txt</button>' +
          '</div>' +
        '</div>';

      var modeSel = $('#mode', root);
      var src = $('#src', root);
      var dst = $('#dst', root);
      var tip = $('#tip', root);
      var stat = $('#stat', root);

      modeSel.addEventListener('change', function () {
        tip.textContent = MODES[modeSel.value].tip;
        stat.textContent = '';
      });

      function updateStat(text) {
        if (!text) { stat.textContent = ''; return; }
        var bytes = toBytes(text).length;
        stat.textContent = text.length + ' 字符 · ' + U.formatBytes(bytes);
      }

      function run(dir) {
        var mode = MODES[modeSel.value];
        var text = src.value;
        if (!text.trim()) { toast('请先输入内容', 'err'); src.focus(); return; }
        try {
          var result = dir === 'enc' ? mode.encode(text) : mode.decode(text);
          dst.value = result;
          updateStat(result);
        } catch (e) {
          dst.value = '';
          stat.textContent = '';
          toast('转换失败：' + (e.message || '输入格式不正确'), 'err');
        }
      }

      $('#enc', root).addEventListener('click', function () { run('enc'); });
      $('#dec', root).addEventListener('click', function () { run('dec'); });

      src.addEventListener('keydown', function (e) {
        if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') { e.preventDefault(); run('enc'); }
      });

      $('#swap', root).addEventListener('click', function () {
        if (!dst.value) return toast('还没有结果', 'err');
        src.value = dst.value;
        dst.value = '';
        stat.textContent = '';
        src.focus();
      });

      $('#clear', root).addEventListener('click', function () {
        src.value = '';
        dst.value = '';
        stat.textContent = '';
      });

      $('#copy', root).addEventListener('click', function () { U.copy(dst.value); });

      $('#download', root).addEventListener('click', function () {
        if (!dst.value) return toast('还没有结果', 'err');
        U.downloadText(dst.value, 'encoded.txt');
      });
    }
  });
})();
