/* ==========================================================================
 * 格式工坊 · core.js
 * 公共工具函数（U）+ 工具注册表（App）
 * 无任何第三方依赖，全部在浏览器本地运行
 * ========================================================================== */
(function () {
  'use strict';

  /* ---------------------------- 图标 ---------------------------- */
  var ICONS = {
    image: '<rect x="3" y="3" width="18" height="18" rx="2.5"/><circle cx="8.6" cy="8.6" r="1.6"/><path d="M20.6 15.6l-4.7-4.7L5 21.5"/>',
    code: '<path d="M16 18l6-6-6-6"/><path d="M8 6l-6 6 6 6"/>',
    braces: '<path d="M8 3H7a2 2 0 0 0-2 2v4a2 2 0 0 1-2 2 2 2 0 0 1 2 2v4a2 2 0 0 0 2 2h1"/><path d="M16 3h1a2 2 0 0 1 2 2v4a2 2 0 0 0 2 2 2 2 0 0 0-2 2v4a2 2 0 0 1-2 2h-1"/>',
    zap: '<path d="M13 2.5L4.5 14H11l-1 7.5L18.5 10H12l1-7.5z"/>',
    palette: '<circle cx="12" cy="12" r="9"/><circle cx="8.4" cy="9.6" r="1.15" fill="currentColor" stroke="none"/><circle cx="12" cy="7.6" r="1.15" fill="currentColor" stroke="none"/><circle cx="15.6" cy="9.6" r="1.15" fill="currentColor" stroke="none"/><circle cx="9.6" cy="14.6" r="1.15" fill="currentColor" stroke="none"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7.4V12l3.3 2"/>',
    hash: '<path d="M4 9h16M4 15h16M10 3L8 21M16 3l-2 18"/>',
    type: '<path d="M4 7V4h16v3"/><path d="M9 20h6"/><path d="M12 4v16"/>',
    file: '<path d="M14 2H6.5A2.5 2.5 0 0 0 4 4.5v15A2.5 2.5 0 0 0 6.5 22h11a2.5 2.5 0 0 0 2.5-2.5V8z"/><path d="M14 2v6h6"/>',
    swap: '<path d="M7 4v13"/><path d="M4 14l3 3 3-3"/><path d="M17 20V7"/><path d="M14 10l3-3 3 3"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.6-3.6"/>',
    sun: '<circle cx="12" cy="12" r="4.2"/><path d="M12 2.6v2M12 19.4v2M2.6 12h2M19.4 12h2M5 5l1.4 1.4M17.6 17.6L19 19M19 5l-1.4 1.4M6.4 17.6L5 19"/>',
    moon: '<path d="M20.5 14.6A8.5 8.5 0 1 1 9.4 3.5a6.9 6.9 0 0 0 11.1 11.1z"/>',
    copy: '<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V6a2 2 0 0 1 2-2h9"/>',
    check: '<path d="M4 12.5l5 5L20 6.5"/>',
    arrow: '<path d="M5 12h14"/><path d="M13 6l6 6-6 6"/>',
    back: '<path d="M19 12H5"/><path d="M11 6l-6 6 6 6"/>',
    upload: '<path d="M12 16.5V4"/><path d="M7 9l5-5 5 5"/><path d="M4 17v2.5A1.5 1.5 0 0 0 5.5 21h13a1.5 1.5 0 0 0 1.5-1.5V17"/>',
    table: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 10h18M9 10v10"/>',
    compress: '<path d="M12 3v6"/><path d="M9 6l3 3 3-3"/><path d="M12 21v-6"/><path d="M9 18l3-3 3 3"/><path d="M4 12h4M16 12h4"/>',
    close: '<path d="M6 6l12 12M18 6L6 18"/>',
    user: '<circle cx="12" cy="8" r="3.8"/><path d="M4.6 20.2c0-3.7 3.4-5.8 7.4-5.8s7.4 2.1 7.4 5.8"/>'
  };

  function icon(name, size) {
    var s = size || 20;
    return (
      '<svg viewBox="0 0 24 24" width="' + s + '" height="' + s + '" fill="none" stroke="currentColor" ' +
      'stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' +
      (ICONS[name] || '') + '</svg>'
    );
  }

  /* ---------------------------- 选择器 ---------------------------- */
  function $(sel, root) { return (root || document).querySelector(sel); }
  function $$(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  /* ---------------------------- 提示 ---------------------------- */
  function toast(msg, kind) {
    var box = document.getElementById('toasts');
    if (!box) return;
    var t = document.createElement('div');
    t.className = 'toast' + (kind ? ' ' + kind : '');
    t.textContent = msg;
    box.appendChild(t);
    requestAnimationFrame(function () { t.classList.add('in'); });
    setTimeout(function () {
      t.classList.remove('in');
      setTimeout(function () { t.remove(); }, 260);
    }, 2200);
  }

  /* ---------------------------- 剪贴板 ---------------------------- */
  function fallbackCopy(text) {
    var ta = document.createElement('textarea');
    ta.value = text;
    ta.setAttribute('readonly', '');
    ta.style.position = 'fixed';
    ta.style.top = '-9999px';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    ta.setSelectionRange(0, text.length);
    var ok = false;
    try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
    ta.remove();
    return ok;
  }

  function copy(text) {
    text = String(text == null ? '' : text);
    if (!text) { toast('没有可复制的内容', 'err'); return; }
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(text).then(function () {
        toast('已复制到剪贴板', 'ok');
      }).catch(function () {
        var ok = fallbackCopy(text);
        toast(ok ? '已复制到剪贴板' : '复制失败，请手动选择', ok ? 'ok' : 'err');
      });
    } else {
      var done = fallbackCopy(text);
      toast(done ? '已复制到剪贴板' : '复制失败，请手动选择', done ? 'ok' : 'err');
    }
  }

  /* ---------------------------- 下载 ----------------------------
   * 预览面板 / 内嵌页通常把页面放进 sandbox iframe，且不带
   * allow-downloads，此时浏览器会静默丢弃下载（控制台只留一行
   * "Download is disallowed"），JS 捕获不到。所以先探测环境，
   * 受限时改为弹出可操作的保存面板。
   * ------------------------------------------------------------ */
  function downloadBlocked() {
    try {
      var fe = window.frameElement;
      if (fe && fe.hasAttribute && fe.hasAttribute('sandbox')) {
        var sb = fe.getAttribute('sandbox') || '';
        return sb.indexOf('allow-downloads') === -1;
      }
    } catch (e) {
      return window.self !== window.top;
    }
    return false;
  }

  function triggerSave(blob, filename, url) {
    var a = document.createElement('a');
    a.href = url;
    a.download = filename || 'download';
    a.rel = 'noopener';
    document.body.appendChild(a);
    a.click();
    a.remove();
  }

  function download(blob, filename) {
    filename = filename || 'download';
    var url = URL.createObjectURL(blob);
    triggerSave(blob, filename, url);

    if (downloadBlocked()) {
      openSavePanel(blob, filename, url);
      return;
    }

    setTimeout(function () { URL.revokeObjectURL(url); }, 60000);
  }

  /* 受限环境下的保存面板 */
  var savePanel = null;

  function closeSavePanel() {
    if (savePanel) { savePanel.remove(); savePanel = null; }
  }

  function openSavePanel(blob, filename, url) {
    closeSavePanel();
    var isImage = /^image\//.test(blob.type || '');
    var box = document.createElement('div');
    box.className = 'savepanel';
    box.innerHTML =
      '<div class="savepanel-card" role="dialog" aria-modal="true" aria-label="保存文件">' +
        '<div class="savepanel-head">' +
          '<div>' +
            '<b>文件已生成，但浏览器拦截了自动下载</b>' +
            '<span>当前是内嵌预览窗口，禁止网页直接保存文件。用下面的方式拿到文件：</span>' +
          '</div>' +
          '<button class="savepanel-x" type="button" aria-label="关闭">' + icon('close', 16) + '</button>' +
        '</div>' +
        '<div class="savepanel-file">' +
          '<span class="savepanel-name">' + escapeHtml(filename) + '</span>' +
          '<span class="savepanel-size">' + formatBytes(blob.size) + '</span>' +
        '</div>' +
        (isImage ? '<img class="savepanel-preview" alt="" src="' + url + '" />' : '') +
        '<div class="savepanel-actions">' +
          '<button class="btn primary" type="button" data-act="open">在新窗口打开</button>' +
          '<button class="btn" type="button" data-act="retry">再试一次下载</button>' +
          '<button class="btn ghost" type="button" data-act="copy">复制页面地址</button>' +
        '</div>' +
        '<p class="savepanel-tip">' +
          (isImage ? '也可以在上面图片上右键（手机长按）→「图片另存为」。' : '') +
          '最稳的方式：把下面地址复制到系统浏览器（Chrome / Edge / Safari）里打开，再下载。' +
        '</p>' +
        '<div class="savepanel-url">' + escapeHtml(location.href) + '</div>' +
      '</div>';

    box.addEventListener('click', function (e) {
      if (e.target === box || e.target.closest('.savepanel-x')) { closeSavePanel(); savePanel = null; return; }
      var btn = e.target.closest('[data-act]');
      if (!btn) return;
      var act = btn.getAttribute('data-act');
      if (act === 'open') {
        var w = null;
        try { w = window.open(url, '_blank'); } catch (err) { w = null; }
        if (!w) toast('新窗口也被拦截了，请复制页面地址到浏览器打开', 'err');
      } else if (act === 'retry') {
        triggerSave(blob, filename, url);
        toast('已重新发起下载，若无反应请复制地址到浏览器', 'warn');
      } else if (act === 'copy') {
        copy(location.href);
      }
    });

    document.body.appendChild(box);
    savePanel = box;
  }

  function downloadText(text, filename, mime) {
    download(new Blob([text], { type: mime || 'text/plain;charset=utf-8' }), filename);
  }

  /* ---------------------------- 杂项 ---------------------------- */
  function formatBytes(bytes) {
    if (!isFinite(bytes)) return '-';
    if (bytes < 1024) return bytes + ' B';
    var kb = bytes / 1024;
    if (kb < 1024) return (kb < 10 ? kb.toFixed(1) : Math.round(kb)) + ' KB';
    var mb = kb / 1024;
    if (mb < 1024) return (mb < 10 ? mb.toFixed(2) : mb.toFixed(1)) + ' MB';
    return (mb / 1024).toFixed(2) + ' GB';
  }

  function escapeHtml(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function debounce(fn, wait) {
    var timer = null;
    return function () {
      var args = arguments, ctx = this;
      clearTimeout(timer);
      timer = setTimeout(function () { fn.apply(ctx, args); }, wait || 200);
    };
  }

  /* ---------------------------- Base64 ---------------------------- */
  function bytesToBase64(bytes) {
    var bin = '';
    var CHUNK = 0x8000;
    for (var i = 0; i < bytes.length; i += CHUNK) {
      bin += String.fromCharCode.apply(null, bytes.subarray(i, i + CHUNK));
    }
    return btoa(bin);
  }

  function base64ToBytes(b64) {
    var bin = atob(b64);
    var out = new Uint8Array(bin.length);
    for (var i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  }

  function textToBase64(str) {
    return bytesToBase64(new TextEncoder().encode(str));
  }

  function base64ToText(b64) {
    return new TextDecoder().decode(base64ToBytes(b64));
  }

  function blobToBase64(blob) {
    return new Promise(function (resolve, reject) {
      var fr = new FileReader();
      fr.onload = function () { resolve(String(fr.result)); };
      fr.onerror = function () { reject(new Error('读取文件失败')); };
      fr.readAsDataURL(blob);
    });
  }

  function dataURLToBlob(dataUrl) {
    var parts = String(dataUrl).split(',');
    var head = parts[0] || '';
    var body = parts.slice(1).join(',') || '';
    var mimeMatch = head.match(/data:([^;]+)/);
    var mime = mimeMatch ? mimeMatch[1] : 'application/octet-stream';
    if (/;base64$/i.test(head) || /;base64;/i.test(head)) {
      var bytes = base64ToBytes(body.replace(/\s/g, ''));
      return new Blob([bytes], { type: mime });
    }
    return new Blob([decodeURIComponent(body)], { type: mime });
  }

  function extFromMime(mime) {
    var map = {
      'image/png': 'png', 'image/jpeg': 'jpg', 'image/jpg': 'jpg', 'image/webp': 'webp',
      'image/gif': 'gif', 'image/bmp': 'bmp', 'image/svg+xml': 'svg', 'image/avif': 'avif',
      'application/pdf': 'pdf', 'application/json': 'json', 'text/plain': 'txt',
      'text/html': 'html', 'text/csv': 'csv', 'audio/mpeg': 'mp3', 'video/mp4': 'mp4',
      'application/zip': 'zip'
    };
    return map[String(mime || '').toLowerCase()] || 'bin';
  }

  /* ---------------------------- 图片 ---------------------------- */
  function loadImage(source) {
    return new Promise(function (resolve, reject) {
      var isUrl = typeof source === 'string';
      var url = isUrl ? source : URL.createObjectURL(source);
      var img = new Image();
      img.onload = function () {
        resolve({
          img: img,
          url: url,
          revoke: function () { if (!isUrl) URL.revokeObjectURL(url); }
        });
      };
      img.onerror = function () {
        if (!isUrl) URL.revokeObjectURL(url);
        reject(new Error('无法解析这张图片'));
      };
      img.src = url;
    });
  }

  function canvasToBlob(canvas, mime, quality) {
    return new Promise(function (resolve, reject) {
      if (canvas.toBlob) {
        canvas.toBlob(function (blob) {
          if (blob) resolve(blob);
          else reject(new Error('当前浏览器不支持导出 ' + mime));
        }, mime, quality);
      } else {
        try { resolve(dataURLToBlob(canvas.toDataURL(mime, quality))); }
        catch (e) { reject(e); }
      }
    });
  }

  /* ---------------------------- ZIP（store，无压缩） ---------------------------- */
  var CRC_TABLE = null;

  function crc32(bytes) {
    if (!CRC_TABLE) {
      CRC_TABLE = new Uint32Array(256);
      for (var n = 0; n < 256; n++) {
        var c = n;
        for (var k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
        CRC_TABLE[n] = c >>> 0;
      }
    }
    var crc = 0xFFFFFFFF;
    for (var i = 0; i < bytes.length; i++) {
      crc = CRC_TABLE[(crc ^ bytes[i]) & 0xFF] ^ (crc >>> 8);
    }
    return (crc ^ 0xFFFFFFFF) >>> 0;
  }

  function dosDateTime(d) {
    return {
      time: (d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1),
      date: ((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate()
    };
  }

  /**
   * 把多个文件打包成 zip（仅 store 模式，不压缩，速度最快）
   * @param {Array<{name:String, blob:Blob}>} items
   * @returns {Promise<Blob>}
   */
  function zipFiles(items) {
    return Promise.all(items.map(function (it) {
      return it.blob.arrayBuffer().then(function (buf) {
        return { name: it.name, data: new Uint8Array(buf) };
      });
    })).then(function (entries) {
      var enc = new TextEncoder();
      var parts = [];
      var central = [];
      var offset = 0;
      var dt = dosDateTime(new Date());

      entries.forEach(function (e) {
        var nameBytes = enc.encode(e.name);
        var crc = crc32(e.data);

        var local = new Uint8Array(30 + nameBytes.length);
        var lv = new DataView(local.buffer);
        lv.setUint32(0, 0x04034b50, true);
        lv.setUint16(4, 20, true);
        lv.setUint16(6, 0x0800, true);          // UTF-8 文件名
        lv.setUint16(8, 0, true);               // store
        lv.setUint16(10, dt.time, true);
        lv.setUint16(12, dt.date, true);
        lv.setUint32(14, crc, true);
        lv.setUint32(18, e.data.length, true);
        lv.setUint32(22, e.data.length, true);
        lv.setUint16(26, nameBytes.length, true);
        lv.setUint16(28, 0, true);
        local.set(nameBytes, 30);

        var cd = new Uint8Array(46 + nameBytes.length);
        var cv = new DataView(cd.buffer);
        cv.setUint32(0, 0x02014b50, true);
        cv.setUint16(4, 20, true);
        cv.setUint16(6, 20, true);
        cv.setUint16(8, 0x0800, true);
        cv.setUint16(10, 0, true);
        cv.setUint16(12, dt.time, true);
        cv.setUint16(14, dt.date, true);
        cv.setUint32(16, crc, true);
        cv.setUint32(20, e.data.length, true);
        cv.setUint32(24, e.data.length, true);
        cv.setUint16(28, nameBytes.length, true);
        cv.setUint16(30, 0, true);
        cv.setUint16(32, 0, true);
        cv.setUint16(34, 0, true);
        cv.setUint16(36, 0, true);
        cv.setUint32(38, 0, true);
        cv.setUint32(42, offset, true);
        cd.set(nameBytes, 46);

        parts.push(local, e.data);
        central.push(cd);
        offset += local.length + e.data.length;
      });

      var cdSize = central.reduce(function (a, c) { return a + c.length; }, 0);
      var eocd = new Uint8Array(22);
      var ev = new DataView(eocd.buffer);
      ev.setUint32(0, 0x06054b50, true);
      ev.setUint16(8, entries.length, true);
      ev.setUint16(10, entries.length, true);
      ev.setUint32(12, cdSize, true);
      ev.setUint32(16, offset, true);

      return new Blob(parts.concat(central, [eocd]), { type: 'application/zip' });
    });
  }

  /* ---------------------------- 导出 ---------------------------- */
  window.U = {
    $: $, $$: $$, icon: icon, toast: toast, copy: copy,
    download: download, downloadText: downloadText, downloadBlocked: downloadBlocked,
    formatBytes: formatBytes, escapeHtml: escapeHtml, debounce: debounce,
    bytesToBase64: bytesToBase64, base64ToBytes: base64ToBytes,
    textToBase64: textToBase64, base64ToText: base64ToText,
    blobToBase64: blobToBase64, dataURLToBlob: dataURLToBlob, extFromMime: extFromMime,
    loadImage: loadImage, canvasToBlob: canvasToBlob, zipFiles: zipFiles
  };

  /* ---------------------------- 工具注册表 ---------------------------- */
  window.App = {
    tools: [],
    register: function (tool) {
      if (!tool || !tool.id) return;
      this.tools.push(tool);
    },
    byId: function (id) {
      for (var i = 0; i < this.tools.length; i++) {
        if (this.tools[i].id === id) return this.tools[i];
      }
      return null;
    }
  };
  window.App.icon = icon;
})();
